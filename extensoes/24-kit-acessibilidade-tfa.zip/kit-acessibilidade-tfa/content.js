(() => {

  let toolbar = null;
  let pendingRange = null;
  let settings = {
    tfaHighlightEnabled: false,
    tfaHighlightColor: '#fff176'
  };

  chrome.storage.sync.get(
    {
      tfaHighlightEnabled: false,
      tfaHighlightColor: '#fff176'
    },
    (stored) => {
      settings = stored;
    }
  );

  chrome.storage.onChanged.addListener((changes) => {

    if (changes.tfaHighlightEnabled) {
      settings.tfaHighlightEnabled =
        changes.tfaHighlightEnabled.newValue;
    }

    if (changes.tfaHighlightColor) {
      settings.tfaHighlightColor =
        changes.tfaHighlightColor.newValue;
    }
  });

  function removeToolbar() {

    if (toolbar) {
      toolbar.remove();
      toolbar = null;
    }

    pendingRange = null;
  }

  function applyHighlight(range) {

    const mark = document.createElement('mark');
    mark.style.backgroundColor = settings.tfaHighlightColor;
    mark.style.color = 'inherit';
    mark.dataset.tfaHighlight = 'true';

    try {
      range.surroundContents(mark);
    } catch (err) {
      mark.appendChild(range.extractContents());
      range.insertNode(mark);
    }
  }

  function showToolbar(range) {

    removeToolbar();

    pendingRange = range;

    const rect = range.getBoundingClientRect();

    toolbar = document.createElement('div');

    toolbar.style.cssText = `
      position: absolute;
      top: ${window.scrollY + rect.bottom + 6}px;
      left: ${window.scrollX + rect.left}px;
      z-index: 2147483647;
      display: flex;
      gap: 4px;
      background: #fff;
      border: 1px solid #dfe3e8;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
      padding: 4px;
      font-family: Arial, sans-serif;
    `;

    const confirmBtn = document.createElement('button');
    confirmBtn.textContent = '✓ Aplicar';
    confirmBtn.style.cssText = `
      cursor: pointer;
      border: none;
      border-radius: 6px;
      padding: 4px 8px;
      font-size: 12px;
      background: #0078d4;
      color: #fff;
    `;

    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = '✕ Cancelar';
    cancelBtn.style.cssText = `
      cursor: pointer;
      border: none;
      border-radius: 6px;
      padding: 4px 8px;
      font-size: 12px;
      background: #f1f3f5;
      color: #333;
    `;

    confirmBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      applyHighlight(pendingRange);
      removeToolbar();
    });

    cancelBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      removeToolbar();
    });

    toolbar.appendChild(confirmBtn);
    toolbar.appendChild(cancelBtn);

    document.body.appendChild(toolbar);
  }

  function handleSelection() {

    const selection = window.getSelection();

    if (!selection ||
      selection.isCollapsed ||
      selection.toString().trim() === '') {
      return;
    }

    // Guarda uma cópia do range: a seleção pode
    // mudar/colapsar ao clicar no toolbar.
    const range = selection.getRangeAt(0).cloneRange();

    showToolbar(range);
  }

  document.addEventListener('mouseup', (e) => {

    if (!settings.tfaHighlightEnabled) {
      return;
    }

    if (toolbar && toolbar.contains(e.target)) {
      return;
    }

    setTimeout(handleSelection, 0);
  });

  document.addEventListener('mousedown', (e) => {

    if (toolbar && !toolbar.contains(e.target)) {
      removeToolbar();
    }
  });

})();
