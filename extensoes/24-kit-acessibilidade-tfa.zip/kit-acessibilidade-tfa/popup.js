document.addEventListener('DOMContentLoaded', () => {

  // ======================
  // TABS
  // ======================

  const tabButtons =
    document.querySelectorAll('.tabBtn');

  const sections =
    document.querySelectorAll('.section');

  tabButtons.forEach(button => {

    button.addEventListener('click', () => {

      tabButtons.forEach(btn =>
        btn.classList.remove('active')
      );

      sections.forEach(section =>
        section.classList.remove('active')
      );

      button.classList.add('active');

      document
        .getElementById(
          button.dataset.tab
        )
        .classList.add('active');
    });

  });

  // ======================
  // TOAST
  // ======================

  const toast =
    document.getElementById('toast');

  function showToast(message) {

    toast.textContent = message;

    toast.classList.add('show');

    setTimeout(() => {
      toast.classList.remove('show');
    }, 1800);
  }

  // ======================
  // LEITOR
  // ======================

  const voiceSelect =
    document.getElementById('voiceSelect');

  const speedRange =
    document.getElementById('speedRange');

  const speedValue =
    document.getElementById('speedValue');

  const readBtn =
    document.getElementById('readBtn');

  const stopBtn =
    document.getElementById('stopBtn');

  let voices = [];

  function loadVoices() {

    voices =
      speechSynthesis.getVoices();

    voiceSelect.innerHTML = '';

    voices.forEach((voice, index) => {

      const option =
        document.createElement('option');

      option.value = index;

      option.textContent =
        `${voice.name} (${voice.lang})`;

      voiceSelect.appendChild(option);
    });
  }

  speechSynthesis.onvoiceschanged =
    loadVoices;

  loadVoices();

  speedRange.addEventListener(
    'input',
    (e) => {

      speedValue.textContent =
        `${e.target.value}x`;
    }
  );

  readBtn.addEventListener(
    'click',
    () => {

      speechSynthesis.cancel();

      chrome.tabs.query(
        {
          active: true,
          currentWindow: true
        },

        (tabs) => {

          chrome.scripting.executeScript({

            target: {
              tabId: tabs[0].id
            },

            func: () => {
              return window
                .getSelection()
                .toString();
            }

          },

          (results) => {

            const text =
              results[0].result;

            if (!text.trim()) {

              showToast(
                '⚠ Selecione um texto'
              );

              return;
            }

            const utterance =
              new SpeechSynthesisUtterance(
                text
              );

            utterance.voice =
              voices[
                voiceSelect.value
              ];

            utterance.rate =
              parseFloat(
                speedRange.value
              );

            speechSynthesis.speak(
              utterance
            );

            showToast(
              '🔊 Lendo texto'
            );
          });
        }
      );
    }
  );

  stopBtn.addEventListener(
    'click',
    () => {

      speechSynthesis.cancel();

      showToast(
        '⏹ Leitura parada'
      );
    }
  );

  // ======================
  // COR
  // ======================

  const colorPicker =
    document.getElementById('colorPicker');

  const previewBox =
    document.getElementById('previewBox');

  const applyBtn =
    document.getElementById('applyBtn');

  const resetBtn =
    document.getElementById('resetBtn');

  const hexValue =
    document.getElementById('hexValue');

  colorPicker.addEventListener(
    'input',
    (e) => {

      previewBox.style.color =
        e.target.value;

      hexValue.textContent =
        e.target.value;
    }
  );

  applyBtn.addEventListener(
    'click',
    () => {

      const color =
        colorPicker.value;

      chrome.tabs.query(
        {
          active: true,
          currentWindow: true
        },

        (tabs) => {

          chrome.scripting.executeScript({

            target: {
              tabId: tabs[0].id
            },

            func: (selectedColor) => {

              document.body.style.color =
                selectedColor;

            },

            args: [color]
          });

          showToast(
            '🎨 Cor aplicada'
          );
        }
      );
    }
  );

  resetBtn.addEventListener(
    'click',
    () => {

      chrome.tabs.query(
        {
          active: true,
          currentWindow: true
        },

        (tabs) => {

          chrome.scripting.executeScript({

            target: {
              tabId: tabs[0].id
            },

            func: () => {

              document.body.style.color =
                '';

            }

          });

          showToast(
            '♻ Cor resetada'
          );
        }
      );
    }
  );

  // ======================
  // MARCA-TEXTO (AUTOMÁTICO)
  // ======================

  const highlightToggle =
    document.getElementById('highlightToggle');

  const highlightColorPicker =
    document.getElementById('highlightColorPicker');

  const highlightHexValue =
    document.getElementById('highlightHexValue');

  const removeHighlightBtn =
    document.getElementById('removeHighlightBtn');

  chrome.storage.sync.get(
    {
      tfaHighlightEnabled: false,
      tfaHighlightColor: '#fff176'
    },

    (settings) => {

      highlightToggle.checked =
        settings.tfaHighlightEnabled;

      highlightColorPicker.value =
        settings.tfaHighlightColor;

      highlightHexValue.textContent =
        settings.tfaHighlightColor;
    }
  );

  highlightToggle.addEventListener(
    'change',
    (e) => {

      chrome.storage.sync.set({
        tfaHighlightEnabled: e.target.checked
      });

      showToast(
        e.target.checked
          ? '🖍 Marca-texto ativado'
          : '🖍 Marca-texto desativado'
      );
    }
  );

  highlightColorPicker.addEventListener(
    'input',
    (e) => {

      highlightHexValue.textContent =
        e.target.value;

      chrome.storage.sync.set({
        tfaHighlightColor: e.target.value
      });
    }
  );

  removeHighlightBtn.addEventListener(
    'click',
    () => {

      chrome.tabs.query(
        {
          active: true,
          currentWindow: true
        },

        (tabs) => {

          chrome.scripting.executeScript({

            target: {
              tabId: tabs[0].id
            },

            func: () => {

              document
                .querySelectorAll('mark[data-tfa-highlight]')
                .forEach((mark) => {

                  const parent =
                    mark.parentNode;

                  while (mark.firstChild) {
                    parent.insertBefore(
                      mark.firstChild,
                      mark
                    );
                  }

                  parent.removeChild(mark);
                });
            }
          });

          showToast('♻ Grifos removidos');
        }
      );
    }
  );

  // ======================
  // ACESSIBILIDADE
  // ======================

  const darkModeBtn =
    document.getElementById('darkModeBtn');

  const fontSelect =
    document.getElementById('fontSelect');

  const zoomInBtn =
    document.getElementById('zoomInBtn');

  const zoomOutBtn =
    document.getElementById('zoomOutBtn');

  const readingModeBtn =
    document.getElementById('readingModeBtn');

  const dyslexiaBtn =
    document.getElementById('dyslexiaBtn');

  // ======================
  // TEMA ESCURO
  // ======================

  let darkModeEnabled = false;

  darkModeBtn.addEventListener(
    'click',
    () => {

      darkModeEnabled =
        !darkModeEnabled;

      if (darkModeEnabled) {

        document.body.style.background =
          '#121212';

        document.body.style.color =
          '#ffffff';

        document
          .querySelectorAll('.section')
          .forEach(section => {

            section.style.background =
              '#1e1e1e';

            section.style.border =
              '1px solid #333';
          });

        showToast(
          '🌙 Tema escuro ativado'
        );

      } else {

        document.body.style.background =
          '#f5f7fa';

        document.body.style.color =
          '#333';

        document
          .querySelectorAll('.section')
          .forEach(section => {

            section.style.background =
              'white';

            section.style.border =
              '1px solid #dfe3e8';
          });

        showToast(
          '☀ Tema escuro desativado'
        );
      }
    }
  );

  // ======================
  // ALTERAR FONTE
  // ======================

  fontSelect.addEventListener(
    'change',
    () => {

      const font =
        fontSelect.value;

      chrome.tabs.query(
        {
          active: true,
          currentWindow: true
        },

        (tabs) => {

          chrome.scripting.executeScript({

            target: {
              tabId: tabs[0].id
            },

            func: (fontFamily) => {

              document.body.style.fontFamily =
                fontFamily;

            },

            args: [font]
          });

          showToast(
            '🔤 Fonte alterada'
          );
        }
      );
    }
  );

  // ======================
  // ZOOM
  // ======================

  zoomInBtn.addEventListener(
    'click',
    () => {

      chrome.tabs.query(
        {
          active: true,
          currentWindow: true
        },

        (tabs) => {

          chrome.tabs.getZoom(
            tabs[0].id,

            (currentZoom) => {

              chrome.tabs.setZoom(
                tabs[0].id,
                currentZoom + 0.1
              );
            }
          );
        }
      );

      showToast(
        '🔍 Zoom +'
      );
    }
  );

  zoomOutBtn.addEventListener(
    'click',
    () => {

      chrome.tabs.query(
        {
          active: true,
          currentWindow: true
        },

        (tabs) => {

          chrome.tabs.getZoom(
            tabs[0].id,

            (currentZoom) => {

              chrome.tabs.setZoom(
                tabs[0].id,
                currentZoom - 0.1
              );
            }
          );
        }
      );

      showToast(
        '🔎 Zoom -'
      );
    }
  );

  // ======================
  // MODO LEITURA
  // ======================

  let readingModeEnabled = false;

  readingModeBtn.addEventListener(
    'click',
    () => {

      readingModeEnabled =
        !readingModeEnabled;

      chrome.tabs.query(
        {
          active: true,
          currentWindow: true
        },

        (tabs) => {

          chrome.scripting.executeScript({

            target: {
              tabId: tabs[0].id
            },

            func: (enabled) => {

              if (enabled) {

                document.body.dataset.reading =
                  'on';

                document.body.style.maxWidth =
                  '850px';

                document.body.style.margin =
                  '40px auto';

                document.body.style.lineHeight =
                  '1.8';

                document.body.style.fontSize =
                  '20px';

                document.body.style.padding =
                  '20px';

              } else {

                document.body.dataset.reading =
                  'off';

                document.body.style.maxWidth =
                  '';

                document.body.style.margin =
                  '';

                document.body.style.lineHeight =
                  '';

                document.body.style.fontSize =
                  '';

                document.body.style.padding =
                  '';
              }

            },

            args: [readingModeEnabled]
          });

          showToast(

            readingModeEnabled
              ? '📖 Modo leitura ativado'
              : '📖 Modo leitura desativado'
          );
        }
      );
    }
  );

  // ======================
  // MODO DISLEXIA
  // ======================

  let dyslexiaEnabled = false;

  dyslexiaBtn.addEventListener(
    'click',
    () => {

      dyslexiaEnabled =
        !dyslexiaEnabled;

      chrome.tabs.query(
        {
          active: true,
          currentWindow: true
        },

        (tabs) => {

          chrome.scripting.executeScript({

            target: {
              tabId: tabs[0].id
            },

            func: (enabled) => {

              if (enabled) {

                document.body.dataset.dyslexia =
                  'on';

                document.body.style.letterSpacing =
                  '1px';

                document.body.style.wordSpacing =
                  '3px';

                document.body.style.lineHeight =
                  '2';

                document.body.style.fontFamily =
                  'Arial';

              } else {

                document.body.dataset.dyslexia =
                  'off';

                document.body.style.letterSpacing =
                  '';

                document.body.style.wordSpacing =
                  '';

                document.body.style.lineHeight =
                  '';

                document.body.style.fontFamily =
                  '';
              }

            },

            args: [dyslexiaEnabled]
          });

          showToast(

            dyslexiaEnabled
              ? '🧠 Modo dislexia ativado'
              : '🧠 Modo dislexia desativado'
          );
        }
      );
    }
  );

});