# Lupa Turbo — Zoom Absurdo 🔍

Extensão de navegador (Chrome/Edge/Brave e outros baseados em Chromium) que
coloca uma lupa flutuante sobre qualquer página, permitindo dar um zoom
extremo (até 30x) em palavras e trechos de texto.

## Como instalar (modo desenvolvedor)

O Chrome não permite instalar arquivos `.zip` diretamente — é preciso
extrair a pasta primeiro.

1. Extraia o arquivo `lupa-turbo.zip` em uma pasta no seu computador.
2. Abra o Chrome e vá em `chrome://extensions`.
3. Ative o **"Modo do desenvolvedor"** (canto superior direito).
4. Clique em **"Carregar sem compactação"** (Load unpacked).
5. Selecione a pasta extraída (a que contém o arquivo `manifest.json`).
6. Pronto! O ícone da lupa aparecerá na barra de extensões.

> Funciona da mesma forma no Microsoft Edge (`edge://extensions`) e no
> Brave (`brave://extensions`).

## Como usar

- Clique no ícone da extensão e depois em **"Ativar Lupa"**, ou use o
  atalho **Alt+Shift+L** em qualquer página.
- A lupa aparece seguindo o cursor do mouse e amplia o texto/conteúdo
  logo abaixo dela.
- Um pequeno painel flutuante aparece no canto da tela com:
  - **Slider de Zoom** (2x a 30x) — dá um zoom "absurdo" em cada palavra.
  - **Slider de Tamanho da lente** — deixa a lupa maior ou menor.
  - **Botão 📌 (fixar)** — trava a lupa no lugar; enquanto fixada, você
    pode clicar e arrastar a própria lupa para reposicioná-la livremente.
  - **Botão ✕** — oculta a lupa instantaneamente.
- Com a lupa ativa, role a roda do mouse **sobre a lente** para ajustar
  o zoom rapidamente, ou use as teclas `+` e `-`.
- Pressione `Esc` a qualquer momento para esconder a lupa.
- O painel de controle também pode ser arrastado pelo ícone ✳️ no topo.

## Detalhes técnicos

- Manifest V3.
- `content.js` clona o conteúdo da página (`document.body`) dentro da
  lente e aplica `transform: scale()` alinhado à posição do cursor —
  por isso é possível ampliar texto de forma nítida, sem depender de
  capturas de tela.
- Um `MutationObserver` mantém o conteúdo clonado atualizado quando a
  página muda.
- As preferências de zoom e tamanho da lente são salvas com
  `chrome.storage.sync` e mantidas entre sessões.

## Limitações conhecidas

- Conteúdo em `<canvas>`, vídeos e alguns componentes muito dinâmicos
  podem não ser espelhados perfeitamente dentro da lente (é uma
  limitação de clonar o DOM, não uma captura de tela real).
- Não funciona em páginas internas do navegador (`chrome://...`) nem na
  Chrome Web Store, por restrição do próprio Chrome.

## Estrutura de arquivos

```
lupa-turbo/
├── manifest.json
├── background.js
├── content.js
├── content.css
├── popup.html
├── popup.css
├── popup.js
├── icons/
│   ├── icon16.png
│   ├── icon32.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```
