(function () {
  if (window.__lupaTurboInjected) return;
  window.__lupaTurboInjected = true;

  const DEFAULTS = { active: false, zoom: 6, size: 220 };
  const MIN_ZOOM = 2;
  const MAX_ZOOM = 30; // zoom absurdo
  const MIN_SIZE = 100;
  const MAX_SIZE = 420;

  const state = { ...DEFAULTS };

  let lens = null;
  let inner = null;
  let panel = null;
  let cloneWrapper = null;
  let mutationObserver = null;
  let refreshTimer = null;
  let dirty = true;

  let lastMouse = { x: window.innerWidth / 2, y: window.innerHeight / 2 };

  /* ---------------- Construção dos elementos ---------------- */

  function buildLens() {
    lens = document.createElement("div");
    lens.id = "lupa-turbo-lens";

    inner = document.createElement("div");
    inner.id = "lupa-turbo-inner";
    lens.appendChild(inner);

    const crosshair = document.createElement("div");
    crosshair.className = "lupa-crosshair";
    lens.appendChild(crosshair);

    document.documentElement.appendChild(lens);
  }

  function buildPanel() {
    panel = document.createElement("div");
    panel.id = "lupa-turbo-panel";
    panel.innerHTML = `
      <div class="lupa-row">
        <span id="lupa-turbo-drag" title="Arraste para mover o painel">&#10021;</span>
        <span class="lupa-title">Lupa Turbo</span>
        <button id="lupa-turbo-pin" title="Fixar a lupa (poder arrastá-la)">&#128204;</button>
        <button id="lupa-turbo-close" title="Ocultar a lupa">&#10005;</button>
      </div>
      <label>Zoom: <span class="lupa-value" id="lupa-turbo-zoom-label">${state.zoom}x</span></label>
      <input type="range" id="lupa-turbo-range" min="${MIN_ZOOM}" max="${MAX_ZOOM}" step="1" value="${state.zoom}">
      <label>Tamanho da lente: <span class="lupa-value" id="lupa-turbo-size-label">${state.size}px</span></label>
      <input type="range" id="lupa-turbo-size-range" min="${MIN_SIZE}" max="${MAX_SIZE}" step="10" value="${state.size}">
      <div class="lupa-hint">
        A lupa segue o cursor. Clique em &#128204; para fixar e arrastar.<br>
        Atalho: <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>L</kbd> mostra/oculta.<br>
        <kbd>Esc</kbd> também oculta.
      </div>
    `;
    document.documentElement.appendChild(panel);

    panel.querySelector("#lupa-turbo-close").addEventListener("click", deactivate);

    const pinBtn = panel.querySelector("#lupa-turbo-pin");
    pinBtn.addEventListener("click", () => {
      state.pinned = !state.pinned;
      pinBtn.classList.toggle("active", state.pinned);
      lens.classList.toggle("lupa-pinned", state.pinned);
    });

    const range = panel.querySelector("#lupa-turbo-range");
    range.addEventListener("input", (e) => {
      setZoom(parseFloat(e.target.value));
    });

    const sizeRange = panel.querySelector("#lupa-turbo-size-range");
    sizeRange.addEventListener("input", (e) => {
      setSize(parseFloat(e.target.value));
    });

    makeDraggable(panel, panel.querySelector("#lupa-turbo-drag"));
    makeLensDraggable();
  }

  function ensureBuilt() {
    if (!lens) buildLens();
    if (!panel) buildPanel();
  }

  /* ---------------- Clonagem da página para ampliar ---------------- */

  function rebuildClone() {
    if (!inner) return;
    inner.innerHTML = "";
    const clone = document.body.cloneNode(true);
    // remove nossos próprios elementos do clone, se tiverem sido pegos
    clone.querySelectorAll("#lupa-turbo-lens, #lupa-turbo-panel").forEach((el) => el.remove());
    clone.style.margin = "0";
    cloneWrapper = clone;
    inner.appendChild(clone);
    dirty = false;
    positionClone();
  }

  function scheduleRebuild() {
    dirty = true;
  }

  function startObservers() {
    mutationObserver = new MutationObserver(() => {
      scheduleRebuild();
    });
    mutationObserver.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      characterData: true,
    });

    refreshTimer = setInterval(() => {
      if (dirty && state.active) rebuildClone();
    }, 350);
  }

  function stopObservers() {
    if (mutationObserver) mutationObserver.disconnect();
    if (refreshTimer) clearInterval(refreshTimer);
    mutationObserver = null;
    refreshTimer = null;
  }

  /* ---------------- Posicionamento / zoom ---------------- */

  function positionLensAt(clientX, clientY) {
    if (!lens) return;
    const half = state.size / 2;
    let left = clientX - half;
    let top = clientY - half;
    lens.style.width = state.size + "px";
    lens.style.height = state.size + "px";
    lens.style.transform = `translate(${left}px, ${top}px)`;
    positionClone(clientX, clientY);
  }

  function positionClone(clientX, clientY) {
    if (!inner) return;
    const cx = clientX !== undefined ? clientX : lastMouse.x;
    const cy = clientY !== undefined ? clientY : lastMouse.y;

    const docX = cx + window.scrollX;
    const docY = cy + window.scrollY;

    const half = state.size / 2;
    const tx = half - docX * state.zoom;
    const ty = half - docY * state.zoom;

    inner.style.transform = `translate(${tx}px, ${ty}px) scale(${state.zoom})`;
  }

  function onMouseMove(e) {
    lastMouse = { x: e.clientX, y: e.clientY };
    if (!state.active || state.pinned) return;
    positionLensAt(e.clientX, e.clientY);
  }

  /* ---------------- Arrastar (quando fixado) ---------------- */

  function makeLensDraggable() {
    let dragging = false;
    let offsetX = 0;
    let offsetY = 0;

    lens.addEventListener("mousedown", (e) => {
      if (!state.pinned) return;
      dragging = true;
      const rect = lens.getBoundingClientRect();
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;
      e.preventDefault();
    });

    window.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      const x = e.clientX - offsetX + state.size / 2;
      const y = e.clientY - offsetY + state.size / 2;
      positionLensAt(x, y);
    });

    window.addEventListener("mouseup", () => {
      dragging = false;
    });
  }

  function makeDraggable(panelEl, handleEl) {
    let dragging = false;
    let offsetX = 0;
    let offsetY = 0;

    handleEl.addEventListener("mousedown", (e) => {
      dragging = true;
      const rect = panelEl.getBoundingClientRect();
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;
      e.preventDefault();
    });

    window.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      const x = e.clientX - offsetX;
      const y = e.clientY - offsetY;
      panelEl.style.left = Math.max(0, x) + "px";
      panelEl.style.top = Math.max(0, y) + "px";
      panelEl.style.right = "auto";
    });

    window.addEventListener("mouseup", () => {
      dragging = false;
    });
  }

  /* ---------------- Controles ---------------- */

  function setZoom(value) {
    state.zoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, value));
    if (panel) {
      panel.querySelector("#lupa-turbo-zoom-label").textContent = state.zoom + "x";
      panel.querySelector("#lupa-turbo-range").value = state.zoom;
    }
    positionClone();
    persist();
  }

  function setSize(value) {
    state.size = Math.min(MAX_SIZE, Math.max(MIN_SIZE, value));
    if (panel) {
      panel.querySelector("#lupa-turbo-size-label").textContent = state.size + "px";
      panel.querySelector("#lupa-turbo-size-range").value = state.size;
    }
    positionLensAt(lastMouse.x, lastMouse.y);
    persist();
  }

  function activate() {
    ensureBuilt();
    state.active = true;
    lens.classList.add("lupa-visible");
    panel.classList.add("lupa-visible");
    rebuildClone();
    startObservers();
    positionLensAt(lastMouse.x, lastMouse.y);
    document.addEventListener("mousemove", onMouseMove, true);
    document.addEventListener("keydown", onKeyDown, true);
    document.addEventListener("wheel", onWheel, { passive: false, capture: true });
    persist();
  }

  function deactivate() {
    state.active = false;
    if (lens) lens.classList.remove("lupa-visible");
    if (panel) panel.classList.remove("lupa-visible");
    stopObservers();
    document.removeEventListener("mousemove", onMouseMove, true);
    document.removeEventListener("keydown", onKeyDown, true);
    document.removeEventListener("wheel", onWheel, { capture: true });
    persist();
  }

  function toggle() {
    if (state.active) deactivate();
    else activate();
    return getState();
  }

  function onKeyDown(e) {
    if (e.key === "Escape") {
      deactivate();
    } else if (e.key === "+" || e.key === "=") {
      setZoom(state.zoom + 1);
    } else if (e.key === "-" || e.key === "_") {
      setZoom(state.zoom - 1);
    }
  }

  function onWheel(e) {
    if (!state.active) return;
    // só intercepta o scroll quando o cursor está sobre a própria lente,
    // para não atrapalhar a rolagem normal da página
    const rect = lens.getBoundingClientRect();
    const withinLens =
      e.clientX >= rect.left &&
      e.clientX <= rect.right &&
      e.clientY >= rect.top &&
      e.clientY <= rect.bottom;
    if (!withinLens) return;
    e.preventDefault();
    const delta = e.deltaY > 0 ? -1 : 1;
    setZoom(state.zoom + delta);
  }

  function getState() {
    return { active: state.active, zoom: state.zoom, size: state.size };
  }

  function persist() {
    try {
      chrome.storage?.sync?.set({
        lupaTurboZoom: state.zoom,
        lupaTurboSize: state.size,
      });
    } catch (e) {
      /* contexto pode ter sido invalidado; ignora */
    }
  }

  function loadPersisted(cb) {
    try {
      chrome.storage?.sync?.get(["lupaTurboZoom", "lupaTurboSize"], (res) => {
        if (res.lupaTurboZoom) state.zoom = res.lupaTurboZoom;
        if (res.lupaTurboSize) state.size = res.lupaTurboSize;
        cb && cb();
      });
    } catch (e) {
      cb && cb();
    }
  }

  /* ---------------- Mensagens da popup / atalho ---------------- */

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.type) {
      case "TOGGLE":
        ensureBuilt();
        sendResponse(toggle());
        break;
      case "GET_STATE":
        ensureBuilt();
        sendResponse(getState());
        break;
      case "SET_ZOOM":
        ensureBuilt();
        setZoom(msg.value);
        sendResponse(getState());
        break;
      case "SET_SIZE":
        ensureBuilt();
        setSize(msg.value);
        sendResponse(getState());
        break;
      default:
        sendResponse(getState());
    }
    return true;
  });

  loadPersisted();

  document.addEventListener("mousemove", (e) => {
    lastMouse = { x: e.clientX, y: e.clientY };
  });
})();
