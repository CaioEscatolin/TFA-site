document.addEventListener("DOMContentLoaded", init);

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function init() {
  const tab = await getActiveTab();
  const toggleBtn = document.getElementById("toggleBtn");
  const zoomRange = document.getElementById("zoomRange");
  const zoomLabel = document.getElementById("zoomLabel");
  const sizeRange = document.getElementById("sizeRange");
  const sizeLabel = document.getElementById("sizeLabel");
  const errorMsg = document.getElementById("errorMsg");

  function updateUI(state) {
    if (!state) return;
    toggleBtn.textContent = state.active ? "Desativar Lupa" : "Ativar Lupa";
    if (state.zoom) {
      zoomRange.value = state.zoom;
      zoomLabel.textContent = state.zoom + "x";
    }
    if (state.size) {
      sizeRange.value = state.size;
      sizeLabel.textContent = state.size + "px";
    }
  }

  function showError() {
    errorMsg.style.display = "block";
    toggleBtn.disabled = true;
  }

  if (!tab || !tab.id) {
    showError();
    return;
  }

  try {
    const state = await chrome.tabs.sendMessage(tab.id, { type: "GET_STATE" });
    updateUI(state);
  } catch (e) {
    showError();
  }

  toggleBtn.addEventListener("click", async () => {
    try {
      const state = await chrome.tabs.sendMessage(tab.id, { type: "TOGGLE" });
      updateUI(state);
    } catch (e) {
      showError();
    }
  });

  zoomRange.addEventListener("input", async (e) => {
    const value = parseFloat(e.target.value);
    zoomLabel.textContent = value + "x";
    try {
      await chrome.tabs.sendMessage(tab.id, { type: "SET_ZOOM", value });
    } catch (e) {
      /* ignora */
    }
  });

  sizeRange.addEventListener("input", async (e) => {
    const value = parseFloat(e.target.value);
    sizeLabel.textContent = value + "px";
    try {
      await chrome.tabs.sendMessage(tab.id, { type: "SET_SIZE", value });
    } catch (e) {
      /* ignora */
    }
  });
}
