chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "toggle-lupa") return;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) return;

  try {
    await chrome.tabs.sendMessage(tab.id, { type: "TOGGLE" });
  } catch (e) {
    // A página pode ser uma aba interna do Chrome onde não é possível injetar
    // scripts (chrome://, Chrome Web Store, etc.). Ignora silenciosamente.
  }
});
