const DEFAULTS = { enabled: false, dwellMs: 1200, scrollEnabled: true, showCursor: true, scrollSpeed: 12 };
const $ = (id) => document.getElementById(id);

function paint(s) {
  $('enabled').checked = s.enabled;
  $('dwellMs').value = s.dwellMs;
  $('dwellVal').textContent = (s.dwellMs / 1000).toFixed(1) + ' s';
  $('scrollSpeed').value = s.scrollSpeed;
  $('speedVal').textContent = s.scrollSpeed;
  $('scrollEnabled').checked = s.scrollEnabled;
  $('showCursor').checked = s.showCursor;
}

chrome.storage.local.get(DEFAULTS, paint);

$('enabled').addEventListener('change', (e) => chrome.storage.local.set({ enabled: e.target.checked }));
$('scrollEnabled').addEventListener('change', (e) => chrome.storage.local.set({ scrollEnabled: e.target.checked }));
$('showCursor').addEventListener('change', (e) => chrome.storage.local.set({ showCursor: e.target.checked }));
$('dwellMs').addEventListener('input', (e) => {
  const v = Number(e.target.value);
  $('dwellVal').textContent = (v / 1000).toFixed(1) + ' s';
  chrome.storage.local.set({ dwellMs: v });
});
$('scrollSpeed').addEventListener('input', (e) => {
  const v = Number(e.target.value);
  $('speedVal').textContent = v;
  chrome.storage.local.set({ scrollSpeed: v });
});
$('calibrate').addEventListener('click', async () => {
  await chrome.storage.local.set({ enabled: true, calibrateNonce: Date.now() });
  window.close();
});
$('reset').addEventListener('click', async () => {
  await chrome.storage.local.set({ calibrated: false, resetNonce: Date.now() });
  $('reset').textContent = '✔ Calibração apagada';
});
$('camera').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('setup.html') });
});

// Mostra os atalhos reais (no Mac aparecem com ⌘). Podem ser mudados em chrome://extensions/shortcuts
chrome.commands.getAll((cmds) => {
  const fmt = (s) => (s ? s.replace('Command', '⌘').replace('Shift', '⇧').replace('Ctrl', '⌃').replace('MacCtrl', '⌃') : 'sem atalho');
  const t = cmds.find((c) => c.name === 'toggle-gaze'), r = cmds.find((c) => c.name === 'recalibrate');
  document.getElementById('sc1').textContent = 'Atalho: ' + fmt(t && t.shortcut);
  document.getElementById('sc2').textContent = 'Recalibrar: ' + fmt(r && r.shortcut);
});
