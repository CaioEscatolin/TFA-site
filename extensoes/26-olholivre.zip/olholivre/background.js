// Service worker: atalhos, configuração inicial e documento offscreen (câmera).
async function injectIntoOpenTabs() {
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*', 'file:///*'] });
  for (const t of tabs) {
    try { await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content.js'] }); } catch (e) { /* aba protegida */ }
  }
}

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') chrome.tabs.create({ url: chrome.runtime.getURL('setup.html') });
  if (details.reason === 'install' || details.reason === 'update') injectIntoOpenTabs();
});

let creating = null;
async function ensureOffscreen() {
  const url = chrome.runtime.getURL('offscreen.html');
  const ctxs = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [url] });
  if (ctxs.length) return;
  if (!creating) {
    creating = chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['USER_MEDIA'],
      justification: 'Acessar a webcam para rastrear o olhar localmente.'
    }).finally(() => { creating = null; });
  }
  await creating;
}

chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'toggle-gaze') {
    const { enabled } = await chrome.storage.local.get({ enabled: false });
    await chrome.storage.local.set({ enabled: !enabled });
  } else if (command === 'recalibrate') {
    await chrome.storage.local.set({ enabled: true, calibrateNonce: Date.now() });
  }
});

let gazeTab = null;
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  // A aba que pede 'attach' passa a receber as mensagens da câmera.
  if (msg.to === 'offscreen' && msg.type === 'attach' && sender.tab) {
    gazeTab = sender.tab.id;
    chrome.storage.session.set({ gazeTab });
  }
  if (msg.to === 'tab') {
    (async () => {
      if (gazeTab == null) gazeTab = (await chrome.storage.session.get({ gazeTab: null })).gazeTab;
      if (gazeTab != null) chrome.tabs.sendMessage(gazeTab, msg, () => void chrome.runtime.lastError);
    })();
    return;
  }
  if (msg.type === 'openSetup') {
    chrome.tabs.create({ url: chrome.runtime.getURL('setup.html') });
  } else if (msg.type === 'ensureCamera') {
    ensureOffscreen().then(() => sendResponse({ ok: true }), (e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  } else if (msg.type === 'closeCamera') {
    chrome.offscreen.closeDocument().catch(() => {});
  }
});
