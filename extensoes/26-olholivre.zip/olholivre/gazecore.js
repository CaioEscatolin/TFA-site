// OlhoLivre – núcleo de estimativa do olhar (matemática pura, sem DOM).
// Entrada: landmarks do MediaPipe FaceMesh (478 pontos, com íris) + pixels dos olhos (WebGazer).
// Saída: posição na tela (normalizada 0..1). Tudo é validado por validação cruzada "deixe um ponto de fora".
(function (root) {
  'use strict';
  const GC = {};

  // ---------------------------------------------------------------- geometria
  // Ordem do vetor g: u, v, vl, e, yaw, pitch, roll, cx, cy, ls
  const GN = 10;
  const SC = [0.10, 0.10, 0.10, 0.10, 0.15, 0.15, 0.20, 0.20, 0.20, 0.15]; // escalas físicas fixas
  const EYE_R = { a: 33, b: 133, up: 159, lo: 145, iris: 468 };   // olho que aparece à esquerda da imagem
  const EYE_L = { a: 362, b: 263, up: 386, lo: 374, iris: 473 };  // olho que aparece à direita da imagem
  const NOSE = 1;

  GC.hasIris = (pts) => !!pts && pts.length >= 478;

  function eyeFeat(P, E) {
    const A = P[E.a], B = P[E.b];
    let ex = B[0] - A[0], ey = B[1] - A[1];
    const w = Math.hypot(ex, ey);
    if (!(w > 4)) return null;
    ex /= w; ey /= w;
    const nx = -ey, ny = ex;                       // perpendicular apontando para baixo na imagem
    const cx = (A[0] + B[0]) / 2, cy = (A[1] + B[1]) / 2;
    const I = P[E.iris], U = P[E.up], L = P[E.lo];
    const dx = I[0] - cx, dy = I[1] - cy;
    const mx = (U[0] + L[0]) / 2, my = (U[1] + L[1]) / 2;
    return {
      u: (dx * ex + dy * ey) / w,                  // íris ao longo do eixo do olho
      v: (dx * nx + dy * ny) / w,                  // íris perpendicular (linha dos cantos)
      vl: ((I[0] - mx) * nx + (I[1] - my) * ny) / w, // íris em relação ao centro das pálpebras
      open: Math.abs((L[0] - U[0]) * nx + (L[1] - U[1]) * ny) / w, // abertura do olho
      cx, cy
    };
  }

  // pts: array de [x,y,z] em pixels do vídeo. Retorna vetor g (10) ou null.
  GC.extractGeometry = function (pts, W, H) {
    if (!GC.hasIris(pts) || !W || !H) return null;
    const r = eyeFeat(pts, EYE_R), l = eyeFeat(pts, EYE_L);
    if (!r || !l) return null;
    const mx = (r.cx + l.cx) / 2, my = (r.cy + l.cy) / 2;
    const iod = Math.hypot(l.cx - r.cx, l.cy - r.cy);
    if (!(iod > 10)) return null;
    const n = pts[NOSE];
    const g = [
      (r.u + l.u) / 2, (r.v + l.v) / 2, (r.vl + l.vl) / 2, (r.open + l.open) / 2,
      (n[0] - mx) / iod, (n[1] - my) / iod, Math.atan2(l.cy - r.cy, l.cx - r.cx),
      mx / W, my / H, Math.log(iod / W)
    ];
    for (let i = 0; i < GN; i++) if (!isFinite(g[i])) return null;
    return g;
  };

  // ---------------------------------------------------------------- mapas de features (G)
  const H6 = [3, 3, 3, 3, 3, 3]; // penalidade extra para termos de cabeça
  const MAPS = [
    { name: 'olhos linear', pen: [1, 1, 1],
      f: (z) => [z[0], z[1], z[2]] },
    { name: 'olhos quadrático', pen: [1, 1, 1, 1, 1, 1],
      f: (z) => [z[0], z[1], z[2], z[0] * z[0], z[2] * z[2], z[0] * z[2]] },
    { name: 'olhos + cabeça', pen: [1, 1, 1, 1, ...H6],
      f: (z) => [z[0], z[1], z[2], z[3], z[4], z[5], z[6], z[7], z[8], z[9]] },
    { name: 'quadrático + cabeça', pen: [1, 1, 1, 1, 1, 1, 1, ...H6],
      f: (z) => [z[0], z[1], z[2], z[3], z[0] * z[0], z[2] * z[2], z[0] * z[2], z[4], z[5], z[6], z[7], z[8], z[9]] },
    { name: 'quadrático + cabeça + interações', pen: [1, 1, 1, 1, 1, 1, 1, ...H6, 6, 6, 6, 6],
      f: (z) => [z[0], z[1], z[2], z[3], z[0] * z[0], z[2] * z[2], z[0] * z[2], z[4], z[5], z[6], z[7], z[8], z[9],
        z[0] * z[4], z[2] * z[5], z[0] * z[5], z[2] * z[4]] },
    { name: 'cúbico + cabeça', pen: [1, 1, 1, 1, 1, 1, 1, ...H6, 6, 6, 6, 6, 3, 3, 3, 3],
      f: (z) => [z[0], z[1], z[2], z[3], z[0] * z[0], z[2] * z[2], z[0] * z[2], z[4], z[5], z[6], z[7], z[8], z[9],
        z[0] * z[4], z[2] * z[5], z[0] * z[5], z[2] * z[4],
        z[0] * z[0] * z[0], z[2] * z[2] * z[2], z[0] * z[0] * z[2], z[0] * z[2] * z[2]] }
  ];
  GC.MAPS = MAPS;
  const LAMBDAS = [1e-4, 3e-4, 1e-3, 3e-3, 1e-2, 3e-2, 0.1, 0.3, 1];
  const LAMBDAS_P = [1e-3, 3e-3, 1e-2, 3e-2, 0.1, 0.3, 1, 3, 10];

  // ---------------------------------------------------------------- álgebra mínima
  // Resolve A x = B (A n×n, B n×m) por eliminação de Gauss com pivoteamento. Retorna n×m ou null.
  function solve(A, B) {
    const n = A.length, m = B[0].length;
    const M = new Array(n);
    for (let i = 0; i < n; i++) { M[i] = new Float64Array(n + m); for (let j = 0; j < n; j++) M[i][j] = A[i][j]; for (let j = 0; j < m; j++) M[i][n + j] = B[i][j]; }
    for (let i = 0; i < n; i++) {
      let p = i;
      for (let r = i + 1; r < n; r++) if (Math.abs(M[r][i]) > Math.abs(M[p][i])) p = r;
      if (Math.abs(M[p][i]) < 1e-12) return null;
      if (p !== i) { const t = M[i]; M[i] = M[p]; M[p] = t; }
      const d = M[i][i];
      for (let r = i + 1; r < n; r++) {
        const f = M[r][i] / d;
        if (f !== 0) for (let c = i; c < n + m; c++) M[r][c] -= f * M[i][c];
      }
    }
    const X = [];
    for (let i = 0; i < n; i++) X.push(new Array(m).fill(0));
    for (let c = 0; c < m; c++) {
      for (let i = n - 1; i >= 0; i--) {
        let s = M[i][n + c];
        for (let j = i + 1; j < n; j++) s -= M[i][j] * X[j][c];
        X[i][c] = s / M[i][i];
      }
    }
    return X;
  }

  const median = (a) => { const b = Array.from(a).sort((p, q) => p - q); const m = b.length >> 1; return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2; };
  GC.median = median;
  const errPx = (px, py, tx, ty, scr) => Math.hypot((px - tx) * scr.w, (py - ty) * scr.h);

  // ---------------------------------------------------------------- limpeza de amostras
  // frames: [{g, px}] de uma mesma fixação. Remove piscadas e movimentos sacádicos/outliers.
  GC.cleanFrames = function (frames) {
    const fr = frames.filter((f) => f && f.g);
    if (fr.length < 4) return fr;
    const me = median(fr.map((f) => f.g[3]));
    let keep = fr.filter((f) => f.g[3] > me * 0.7);                    // pálpebra aberta
    if (keep.length < 4) keep = fr;
    const mu = median(keep.map((f) => f.g[0])), mv = median(keep.map((f) => f.g[2]));
    const su = Math.max(1.4826 * median(keep.map((f) => Math.abs(f.g[0] - mu))), 0.004);
    const sv = Math.max(1.4826 * median(keep.map((f) => Math.abs(f.g[2] - mv))), 0.004);
    const k2 = keep.filter((f) => Math.abs(f.g[0] - mu) < 3.5 * su && Math.abs(f.g[2] - mv) < 3.5 * sv);
    return k2.length >= 4 ? k2 : keep;
  };

  // ---------------------------------------------------------------- ridge primal por estatísticas
  function buildStats(Phis, Ys, ws, p1) {
    const A = []; for (let i = 0; i < p1; i++) A.push(new Float64Array(p1));
    const b = [new Float64Array(p1), new Float64Array(p1)];
    for (let k = 0; k < Phis.length; k++) {
      const v = Phis[k], w = ws[k], y = Ys[k];
      for (let i = 0; i < p1; i++) {
        const wi = w * v[i]; b[0][i] += wi * y[0]; b[1][i] += wi * y[1];
        for (let j = i; j < p1; j++) A[i][j] += wi * v[j];
      }
    }
    for (let i = 0; i < p1; i++) for (let j = 0; j < i; j++) A[i][j] = A[j][i];
    return { A, b };
  }
  function ridgeSolve(A, b, pen, lam, subA, subB) {
    const p1 = A.length, R = [], B = [];
    for (let i = 0; i < p1; i++) {
      const row = new Array(p1);
      for (let j = 0; j < p1; j++) row[j] = A[i][j] - (subA ? subA[i][j] : 0);
      row[i] += i === 0 ? 1e-9 : lam * pen[i - 1];
      R.push(row);
      B.push([b[0][i] - (subB ? subB[0][i] : 0), b[1][i] - (subB ? subB[1][i] : 0)]);
    }
    const X = solve(R, B);
    return X ? [X.map((r) => r[0]), X.map((r) => r[1])] : null;
  }
  const dotv = (beta, v) => { let s = beta[0]; for (let i = 0; i < v.length; i++) s += beta[i + 1] * v[i]; return s; };

  // ---------------------------------------------------------------- ajuste do modelo
  // groups: [{id,tx,ty,val,gw,frames:[g...],pm:[px médios]|null}]
  // hp (opcional): hiperparâmetros congelados -> sem seleção, só reajusta (usado ao refinar com cliques).
  GC.fitModel = function (groups, scr, hp) {
    groups = groups.filter((g) => g.frames && g.frames.length >= 4);
    if (groups.length < 8) return null;
    const gws = groups.map((g) => g.gw || 1), sumGw = gws.reduce((a, b) => a + b, 0);
    const gm = new Array(GN).fill(0);
    let wsum = 0;
    groups.forEach((g, gi) => g.frames.forEach((fg) => { const w = gws[gi] / g.frames.length; for (let i = 0; i < GN; i++) gm[i] += w * fg[i]; wsum += w; }));
    for (let i = 0; i < GN; i++) gm[i] /= wsum;
    const zOf = (g) => g.map((x, i) => (x - gm[i]) / SC[i]);

    const out = { v: 2, scr, gm, G: null, P: null, wG: 0, wP: 0, hp: {}, cv: {} };
    const oofG = [], oofP = []; // previsões fora-da-amostra por grupo (nível de grupo)

    // ---------- G (geometria da íris + cabeça)
    const gData = groups.map((g, gi) => g.frames.map((fg) => zOf(fg)));
    let bestMap = -1, bestLam = 0, bestErr = Infinity;
    const cvG = (mi, lam, keepOof) => {
      const map = MAPS[mi], p1 = map.pen.length + 1;
      const stats = groups.map((g, gi) => {
        const Phis = gData[gi].map((z) => [1, ...map.f(z)]);
        const Ys = gData[gi].map(() => [g.tx, g.ty]);
        const ws = gData[gi].map(() => gws[gi] / sumGw / gData[gi].length);
        return { ...buildStats(Phis, Ys, ws, p1), Phis };
      });
      const TA = []; for (let i = 0; i < p1; i++) TA.push(new Float64Array(p1));
      const TB = [new Float64Array(p1), new Float64Array(p1)];
      stats.forEach((s) => { for (let i = 0; i < p1; i++) { for (let j = 0; j < p1; j++) TA[i][j] += s.A[i][j]; TB[0][i] += s.b[0][i]; TB[1][i] += s.b[1][i]; } });
      let tot = 0, wt = 0; const oof = [];
      for (let gi = 0; gi < groups.length; gi++) {
        if (groups[gi].live) { oof.push(null); continue; }       // cliques ao vivo não entram na validação
        const beta = ridgeSolve(TA, TB, map.pen, lam, stats[gi].A, stats[gi].b);
        if (!beta) return { err: Infinity };
        let px = 0, py = 0; const n = stats[gi].Phis.length;
        stats[gi].Phis.forEach((v) => { px += dotv(beta[0], v.slice(1)); py += dotv(beta[1], v.slice(1)); });
        px /= n; py /= n; oof.push([px, py]);
        tot += errPx(px, py, groups[gi].tx, groups[gi].ty, scr); wt++;
      }
      return { err: wt ? tot / wt : Infinity, oof, stats, TA, TB, p1 };
    };
    if (hp && hp.map != null) { bestMap = hp.map; bestLam = hp.lamG; }
    else {
      for (let mi = 0; mi < MAPS.length; mi++) {
        let mBest = Infinity, mLam = LAMBDAS[0];
        for (const lam of LAMBDAS) { const r = cvG(mi, lam); if (r.err < mBest) { mBest = r.err; mLam = lam; } }
        if (mBest < bestErr * 0.97) { bestErr = mBest; bestMap = mi; bestLam = mLam; } // só troca por modelo mais complexo se melhorar >3%
      }
    }
    if (bestMap >= 0 && isFinite(bestErr) || (hp && hp.map != null)) {
      const r = cvG(bestMap, bestLam);
      const beta = r.TA ? ridgeSolve(r.TA, r.TB, MAPS[bestMap].pen, bestLam) : null;
      if (beta) {
        out.G = { map: bestMap, beta };
        out.hp.map = bestMap; out.hp.lamG = bestLam;
        out.cv.errG = r.err; r.oof.forEach((o, i) => (oofG[i] = o));
      }
    }

    // ---------- P (pixels dos olhos do WebGazer, forma dual)
    const withPm = groups.map((g, i) => i).filter((i) => groups[i].pm && groups[i].pm.length);
    if (withPm.length >= 8) {
      const D = groups[withPm[0]].pm.length;
      const fitP = (idx, lam) => {
        const n = idx.length; let ws = 0; const xm = new Float64Array(D); const ym = [0, 0];
        idx.forEach((i) => { const w = gws[i]; ws += w; for (let d = 0; d < D; d++) xm[d] += w * groups[i].pm[d] / 255; ym[0] += w * groups[i].tx; ym[1] += w * groups[i].ty; });
        for (let d = 0; d < D; d++) xm[d] /= ws; ym[0] /= ws; ym[1] /= ws;
        const Xw = idx.map((i) => { const sw = Math.sqrt(gws[i] / ws * n / n); const r = new Float64Array(D); for (let d = 0; d < D; d++) r[d] = sw * (groups[i].pm[d] / 255 - xm[d]); return r; });
        const Yw = idx.map((i) => { const sw = Math.sqrt(gws[i] / ws); return [sw * (groups[i].tx - ym[0]), sw * (groups[i].ty - ym[1])]; });
        const K = []; for (let a = 0; a < n; a++) { K.push(new Float64Array(n)); }
        for (let a = 0; a < n; a++) for (let b = a; b < n; b++) { let s = 0; for (let d = 0; d < D; d++) s += Xw[a][d] * Xw[b][d]; K[a][b] = s; K[b][a] = s; }
        const lams = lam != null ? [lam] : LAMBDAS_P;
        return { xm, ym, Xw, Yw, K, lams, n, D };
      };
      const solveP = (st, lam) => {
        const R = st.K.map((r, i) => { const row = Array.from(r); row[i] += lam; return row; });
        const al = solve(R, st.Yw);
        if (!al) return null;
        const beta = [new Float64Array(st.D), new Float64Array(st.D)];
        for (let a = 0; a < st.n; a++) for (let d = 0; d < st.D; d++) { beta[0][d] += st.Xw[a][d] * al[a][0]; beta[1][d] += st.Xw[a][d] * al[a][1]; }
        return beta;
      };
      const predP = (beta, xm, ym, pm) => { let x = ym[0], y = ym[1]; for (let d = 0; d < xm.length; d++) { const v = pm[d] / 255 - xm[d]; x += beta[0][d] * v; y += beta[1][d] * v; } return [x, y]; };
      let bestL = hp && hp.lamP != null ? hp.lamP : null, bestPe = Infinity, oofBest = null;
      const calIdx = withPm.filter((i) => !groups[i].live);
      if (bestL == null) {
        const errs = LAMBDAS_P.map(() => 0), cnt = LAMBDAS_P.map(() => 0), oofs = LAMBDAS_P.map(() => []);
        for (const gi of calIdx) {
          const idx = withPm.filter((i) => i !== gi);
          const st = fitP(idx, null);
          LAMBDAS_P.forEach((lam, li) => {
            const beta = solveP(st, lam); if (!beta) { errs[li] = Infinity; return; }
            const [px, py] = predP(beta, st.xm, st.ym, groups[gi].pm);
            errs[li] += errPx(px, py, groups[gi].tx, groups[gi].ty, scr); cnt[li]++; oofs[li][gi] = [px, py];
          });
        }
        LAMBDAS_P.forEach((lam, li) => { const e = errs[li] / Math.max(1, cnt[li]); if (e < bestPe) { bestPe = e; bestL = lam; oofBest = oofs[li]; } });
      }
      const st = fitP(withPm, null), beta = solveP(st, bestL);
      if (beta && isFinite(bestL)) {
        out.P = { xm: Array.from(st.xm), ym: st.ym, beta: [Array.from(beta[0]), Array.from(beta[1])] };
        out.hp.lamP = bestL; out.cv.errP = bestPe;
        if (oofBest) oofBest.forEach((o, i) => (oofP[i] = o));
      }
    }

    // ---------- fusão G + P (peso que minimiza o erro fora-da-amostra)
    if (hp && hp.wG != null) { out.wG = out.G ? hp.wG : 0; out.wP = out.P ? 1 - out.wG : 0; if (!out.G && out.P) out.wP = 1; }
    else if (out.G && out.P) {
      let bw = 1, be = Infinity;
      for (let w = 0; w <= 1.0001; w += 0.1) {
        let tot = 0, n = 0;
        groups.forEach((g, i) => { if (!oofG[i] || !oofP[i]) return; tot += errPx(w * oofG[i][0] + (1 - w) * oofP[i][0], w * oofG[i][1] + (1 - w) * oofP[i][1], g.tx, g.ty, scr); n++; });
        const e = n ? tot / n : Infinity; if (e < be - 1e-9) { be = e; bw = w; }
      }
      out.wG = bw; out.wP = 1 - bw; out.cv.err = be;
    } else if (out.G) { out.wG = 1; out.cv.err = out.cv.errG; }
    else if (out.P) { out.wP = 1; out.cv.err = out.cv.errP; }
    else return null;
    out.hp.wG = out.wG;
    out.mapName = out.G ? MAPS[out.G.map].name : 'só pixels';
    return out;
  };

  // ---------------------------------------------------------------- previsão
  // g: vetor geométrico (10) ou null; pxv: pixels (120) ou null. Retorna {x,y} normalizado ou null.
  GC.predict = function (model, g, pxv) {
    if (!model) return null;
    let gx = null, gy = null, px = null, py = null;
    if (model.G && g) {
      const z = g.map((x, i) => (x - model.gm[i]) / SC[i]);
      const phi = MAPS[model.G.map].f(z);
      gx = dotv(model.G.beta[0], phi); gy = dotv(model.G.beta[1], phi);
    }
    if (model.P && pxv) {
      px = model.P.ym[0]; py = model.P.ym[1];
      for (let d = 0; d < model.P.xm.length; d++) { const v = pxv[d] / 255 - model.P.xm[d]; px += model.P.beta[0][d] * v; py += model.P.beta[1][d] * v; }
    }
    let x, y;
    if (gx != null && px != null) { x = model.wG * gx + model.wP * px; y = model.wG * gy + model.wP * py; }
    else if (gx != null) { x = gx; y = gy; }
    else if (px != null) { x = px; y = py; }
    else return null;
    if (!isFinite(x) || !isFinite(y)) return null;
    return { x: Math.max(-0.5, Math.min(1.5, x)), y: Math.max(-0.5, Math.min(1.5, y)) };
  };

  // Erro médio (px) do modelo em grupos de verificação. `err` é por quadro (o que o usuário sente ao vivo,
  // antes da suavização); `errMean` usa a previsão média do grupo. `points` traz a previsão média para exibir.
  GC.evalGroups = function (model, groups, scr) {
    const pts = []; let tot = 0, totMean = 0, nFrames = 0;
    for (const g of groups) {
      let sx = 0, sy = 0, n = 0;
      g.frames.forEach((fg) => {
        const p = GC.predict(model, fg, g.pm);
        if (p) { sx += p.x; sy += p.y; n++; tot += errPx(p.x, p.y, g.tx, g.ty, scr); nFrames++; }
      });
      if (!n) continue;
      const px = sx / n, py = sy / n, e = errPx(px, py, g.tx, g.ty, scr);
      pts.push({ tx: g.tx, ty: g.ty, px, py, err: e }); totMean += e;
    }
    return { err: nFrames ? tot / nFrames : null, errMean: pts.length ? totMean / pts.length : null, points: pts };
  };

  // ---------------------------------------------------------------- persistência compacta
  const r5 = (a) => a.map((x) => Math.round(x * 1e5) / 1e5);
  GC.packGroups = (groups) => groups.map((g) => ({ id: g.id, tx: g.tx, ty: g.ty, val: !!g.val, live: !!g.live, gw: g.gw || 1,
    frames: g.frames.map(r5), pm: g.pm ? g.pm.map((x) => Math.round(x * 10) / 10) : null }));
  GC.round = r5;

  root.GazeCore = GC;
  if (typeof module !== 'undefined' && module.exports) module.exports = GC;
})(typeof self !== 'undefined' ? self : this);
