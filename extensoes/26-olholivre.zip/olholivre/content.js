// OlhoLivre – script de conteúdo: cursor do olhar, clique por permanência e rolagem por bordas.
(() => {
  if (window.top !== window) return;
  if (window.__olhoLivreLoaded) return; // evita injeção dupla
  window.__olhoLivreLoaded = true;

  const DEFAULTS = {
    enabled: false, dwellMs: 1200, scrollEnabled: true, showCursor: true,
    scrollSpeed: 12, calibrated: false, calibErr: null
  };
  const EDGE = 0.12;         // fração da tela (topo/base) que dispara a rolagem
  const EDGE_DELAY = 350;    // ms olhando a borda antes de rolar
  let dwellRadius = 55;      // px que o olhar pode oscilar sem reiniciar o clique (ajustado pelo erro medido)

  let S = { ...DEFAULTS };
  let active = false, linked = false, pingTimer = 0, ready = false, calibrating = false, pendingCalibrate = false;
  let host, root, dot, ring, toast, toastTimer, calibBox, toastKind = '';
  let sx = 0, sy = 0, hasGaze = false;
  let ax = 0, ay = 0, dwellStart = 0;
  let edgeSince = 0, raf = 0, startTimer = 0;
  let lastCalibNonce, lastResetNonce;
  let lastPose = null, driftCount = 0, lastDriftWarn = 0;
  const waiters = {};

  // ---------- Geometria: coordenadas da TELA (valem mesmo se a janela mudar de tamanho/posição) ----------
  function geo() {
    const sw = screen.width, sh = screen.height;
    const ox = (window.screenX || 0) + Math.max(0, Math.min(20, (outerWidth - innerWidth) / 2));
    const oy = (window.screenY || 0) + Math.max(0, Math.min(220, outerHeight - innerHeight));
    const ok = sw > 0 && sh > 0 && ox > -40 && oy > -40 && ox + innerWidth <= sw * 1.03 && oy + innerHeight <= sh * 1.03 && innerWidth > sw * 0.2;
    return ok ? { sw, sh, ox, oy } : { sw: innerWidth, sh: innerHeight, ox: 0, oy: 0 }; // plano B: coordenadas da janela
  }
  const vToScr = (x, y) => { const g = geo(); return [(g.ox + x) / g.sw, (g.oy + y) / g.sh]; };
  const scrToV = (nx, ny) => { const g = geo(); return [nx * g.sw - g.ox, ny * g.sh - g.oy]; };

  // ---------- Filtro One-Euro (suave ao fixar, sem atraso nos movimentos rápidos) ----------
  function makeOneEuro(minCut, beta, dCut) {
    let px = 0, py = 0, pdx = 0, pdy = 0, pt = 0, has = false;
    const alpha = (c, dt) => 1 / (1 + (1 / (2 * Math.PI * c)) / dt);
    return {
      reset() { has = false; },
      f(x, y, t) {
        if (!has) { has = true; px = x; py = y; pdx = pdy = 0; pt = t; return [x, y]; }
        const dt = Math.max((t - pt) / 1000, 0.008);
        const ad = alpha(dCut, dt);
        pdx += ad * ((x - px) / dt - pdx); pdy += ad * ((y - py) / dt - pdy);
        const a = alpha(minCut + beta * Math.hypot(pdx, pdy), dt);
        px += a * (x - px); py += a * (y - py); pt = t;
        return [px, py];
      }
    };
  }
  const oneEuro = makeOneEuro(1.0, 0.01, 1.0);

  function updateRadius() {
    dwellRadius = S.calibErr ? Math.max(45, Math.min(120, 0.9 * S.calibErr + 25)) : 55;
  }

  // ---------- UI ----------
  function buildUI() {
    if (host) return;
    host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;inset:0;pointer-events:none;z-index:2147483647;';
    dot = document.createElement('div');
    dot.style.cssText = 'position:fixed;left:0;top:0;width:14px;height:14px;margin:-7px 0 0 -7px;border-radius:50%;' +
      'background:rgba(34,211,238,.9);box-shadow:0 0 0 2px #fff,0 0 10px #22d3ee;display:none;pointer-events:none;will-change:transform;';
    ring = document.createElement('div');
    ring.style.cssText = 'position:fixed;left:0;top:0;width:56px;height:56px;margin:-28px 0 0 -28px;border-radius:50%;' +
      'display:none;pointer-events:none;will-change:transform;' +
      '-webkit-mask:radial-gradient(farthest-side,transparent calc(100% - 6px),#000 calc(100% - 5px));' +
      'mask:radial-gradient(farthest-side,transparent calc(100% - 6px),#000 calc(100% - 5px));';
    toast = document.createElement('div');
    toast.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:#0f172acc;color:#e2e8f0;' +
      'font:600 14px system-ui,sans-serif;padding:10px 16px;border-radius:10px;display:none;pointer-events:none;max-width:80vw;text-align:center;';
    calibBox = document.createElement('div');
    calibBox.style.cssText = 'position:fixed;inset:0;display:none;pointer-events:auto;background:rgba(15,23,42,.88);color:#e2e8f0;font:14px system-ui,sans-serif;cursor:default;';
    root = host.attachShadow({ mode: 'closed' });
    root.append(ring, dot, toast, calibBox);
    document.documentElement.appendChild(host);
  }

  function say(text, ms = 3000) {
    buildUI();
    toastKind = '';
    toast.textContent = '👁️ ' + text;
    toast.style.display = 'block';
    clearTimeout(toastTimer);
    if (ms) toastTimer = setTimeout(() => (toast.style.display = 'none'), ms);
  }

  function hideCursor() { if (dot) { dot.style.display = 'none'; ring.style.display = 'none'; } }

  // ---------- Ciclo de vida ----------
  function sync() {
    const should = S.enabled && document.visibilityState === 'visible';
    if (should && !active) start();
    else if (!should && active) stop();
    if (!S.showCursor) hideCursor();
  }

  function start() {
    buildUI();
    active = true;
    say('Iniciando câmera…', 0);
    raf = requestAnimationFrame(tick);
    clearTimeout(startTimer);
    startTimer = setTimeout(() => {
      if (active && !ready) {
        stop();
        say('Não foi possível iniciar a câmera. Clique em "Permitir câmera" no ícone da extensão e tente de novo.', 9000);
        chrome.storage.local.set({ enabled: false });
      }
    }, 25000);
    chrome.runtime.sendMessage({ type: 'ensureCamera' }, (r) => {
      if (!active) return;
      if (chrome.runtime.lastError || !r || !r.ok) {
        console.error('[OlhoLivre] offscreen', chrome.runtime.lastError && chrome.runtime.lastError.message, r && r.error);
        stop();
        say('Erro ao iniciar a câmera: ' + ((r && r.error) || (chrome.runtime.lastError && chrome.runtime.lastError.message) || ''), 8000);
        chrome.storage.local.set({ enabled: false });
        return;
      }
      linked = true;
      post({ type: 'attach', scr: { w: screen.width, h: screen.height } });
      clearInterval(pingTimer);
      pingTimer = setInterval(() => post({ type: 'ping' }), 5000);
    });
  }

  function stop() {
    active = false; linked = false; calibAbort = true; oneEuro.reset(); post({ type: 'cal:cancel' });
    clearTimeout(startTimer);
    clearInterval(pingTimer);
    cancelAnimationFrame(raf);
    ready = calibrating = hasGaze = false;
    if (calibBox) { calibBox.style.display = 'none'; calibBox.textContent = ''; }
    hideCursor();
    if (toast) toast.style.display = 'none';
  }

  function post(m) {
    try { chrome.runtime.sendMessage({ to: 'offscreen', ...m }, () => void chrome.runtime.lastError); } catch (e) { /* extensão recarregada */ }
  }
  function normTrain(x, y) { if (linked) { const [nx, ny] = vToScr(x, y); post({ type: 'train', x: nx, y: ny }); } }

  // ---------- Calibração: posicionamento -> 25 pontos -> 8 pontos de verificação -> resumo ----------
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const SETTLE = 650;      // ms para o olho chegar ao ponto antes de gravar
  const COLLECT = 1000;    // ms gravando (~25 quadros)
  const MAX_RETRY = 2;     // repete o ponto se houve piscada/movimento demais
  let calibAbort = false, runId = 0, finalRes = null;

  const TRAIN_AXIS = [5, 27.5, 50, 72.5, 95];
  const VALIDATION = [[16, 17], [83, 15], [39, 40], [63, 35], [17, 60], [61, 66], [85, 80], [40, 86]];
  function gridPoints() {
    const pts = [];
    TRAIN_AXIS.forEach((y, i) => { const row = TRAIN_AXIS.map((x) => [x, y]); if (i % 2) row.reverse(); pts.push(...row); });
    return pts;
  }
  function waitMsg(type, ms) {
    return new Promise((res) => {
      const t = setTimeout(() => { delete waiters[type]; res(null); }, ms);
      waiters[type] = (m) => { clearTimeout(t); delete waiters[type]; res(m); };
    });
  }
  const poseFresh = () => lastPose && performance.now() - lastPose.t < 1500 && lastPose.face;

  function checksFor(p) {
    const fresh = !!(p && performance.now() - p.t < 1500 && p.face);
    const iris = fresh && p.iris;
    const cOk = iris && Math.abs(p.cx - 0.5) < 0.2 && Math.abs(p.cy - 0.45) < 0.22;
    const dOk = iris && p.s >= 0.10 && p.s <= 0.34;
    const rOk = iris && Math.abs(p.roll) < 0.3;
    const lOk = fresh && p.bright >= 40 && p.bright <= 225;
    const rows = [
      [fresh && iris !== false, fresh ? 'Rosto detectado' : 'Rosto não detectado: olhe para a câmera'],
      [cOk, cOk ? 'Rosto centralizado' : 'Centralize o rosto na câmera'],
      [dOk, dOk ? 'Distância boa' : (iris && p.s < 0.10 ? 'Muito longe: aproxime-se' : iris && p.s > 0.34 ? 'Muito perto: afaste-se' : 'Distância ideal: ~50-70 cm')],
      [rOk, rOk ? 'Cabeça na vertical' : 'Endireite a cabeça'],
      [lOk, lOk ? 'Iluminação boa' : (fresh && p.bright > 225 ? 'Luz forte demais nos olhos' : 'Pouca luz: acenda uma luz à frente do rosto')]
    ];
    return { rows, hard: !!(fresh && iris && cOk && dOk && rOk) };
  }

  async function runCalibration() {
    calibrating = true; calibAbort = false; hasGaze = false; finalRes = null;
    const myRun = ++runId;
    const stale = () => calibAbort || myRun !== runId;
    hideCursor();
    if (toast) toast.style.display = 'none';
    lastPose = null;
    post({ type: 'cal:begin', scr: { w: screen.width, h: screen.height } });
    post({ type: 'poseStream', on: true });

    calibBox.textContent = '';
    const msg = document.createElement('div');
    msg.style.cssText = 'position:absolute;left:50%;top:20%;transform:translate(-50%,-50%);text-align:center;max-width:520px;pointer-events:none;line-height:1.5;';
    const title = document.createElement('h2'); title.style.cssText = 'margin:0 0 6px;font-size:22px';
    const sub = document.createElement('p'); sub.style.cssText = 'margin:0;color:#94a3b8';
    const checks = document.createElement('div'); checks.style.cssText = 'margin-top:14px;text-align:left;display:inline-block;font-size:14px;line-height:1.9;';
    msg.append(title, sub, checks);
    const warn = document.createElement('div');
    warn.style.cssText = 'position:absolute;left:50%;bottom:70px;transform:translateX(-50%);background:#b45309;color:#fff;font-weight:600;padding:10px 16px;border-radius:10px;display:none;pointer-events:none;';
    const bar = document.createElement('div'); bar.style.cssText = 'position:absolute;left:0;bottom:0;height:5px;width:0;background:#22d3ee;transition:width .3s;';
    const cancel = document.createElement('button');
    cancel.textContent = 'Cancelar (Esc)';
    cancel.style.cssText = 'position:absolute;right:16px;bottom:16px;background:#334155;color:#e2e8f0;border:0;border-radius:8px;padding:8px 14px;cursor:pointer;font:inherit;';
    cancel.addEventListener('click', () => endCalibration(false));
    const dotC = document.createElement('div');
    dotC.style.cssText = 'position:absolute;left:0;top:0;width:44px;height:44px;margin:-22px 0 0 -22px;border-radius:50%;' +
      'border:3px solid #22d3ee;background:rgba(34,211,238,.35);transition:left .25s ease,top .25s ease;display:none;pointer-events:none;';
    const core = document.createElement('div');
    core.style.cssText = 'position:absolute;left:50%;top:50%;width:8px;height:8px;margin:-4px 0 0 -4px;border-radius:50%;background:#fff;';
    dotC.appendChild(core);
    calibBox.append(msg, dotC, warn, bar, cancel);
    calibBox.style.display = 'block';

    const place = (pctx, pcty, color) => {
      dotC.style.display = 'block';
      dotC.style.left = (innerWidth * pctx / 100) + 'px';
      dotC.style.top = (innerHeight * pcty / 100) + 'px';
      dotC.style.borderColor = color; dotC.style.background = color + '59';
      dotC.animate([{ transform: 'scale(1.6)' }, { transform: 'scale(0.7)' }], { duration: SETTLE + COLLECT, easing: 'ease-out' });
    };

    // ---- 1) Posicionamento
    title.textContent = 'Posicione-se';
    sub.innerHTML = 'Sente-se confortável, com o rosto no centro da câmera, olhando para a tela.<br>Depois disso, tente <b>manter a cabeça parada</b>.';
    let okSince = 0; const t0 = performance.now();
    while (!stale()) {
      await sleep(150);
      const c = checksFor(lastPose), now = performance.now();
      checks.textContent = '';
      c.rows.forEach(([ok, txt]) => {
        const d = document.createElement('div');
        d.textContent = (ok ? '✔ ' : '✖ ') + txt;
        d.style.color = ok ? '#4ade80' : '#fbbf24';
        checks.appendChild(d);
      });
      if (c.hard) { if (!okSince) okSince = now; if (now - okSince > 1400) break; } else okSince = 0;
      if (now - t0 > 30000) { if (!(poseFresh() && lastPose.iris)) { endCalibration(false, null, 'Não consegui ver seu rosto com a câmera. Verifique a luz e a câmera e tente de novo.'); return; } break; }
    }
    if (stale()) return;
    checks.textContent = '';
    post({ type: 'setRef' });
    await sleep(200);

    // ---- 2) Pontos
    sub.innerHTML = '<b>Olhe fixamente</b> para o ponto, sem clicar. Se piscar, tudo bem.';
    const train = gridPoints();
    const val = VALIDATION.map((p) => p.slice()).sort(() => Math.random() - 0.5);
    const total = train.length + val.length;
    let done = 0;

    const waitPose = async () => {
      let since = 0;
      while (!stale()) {
        if (poseFresh() && lastPose.iris && lastPose.drift < 1.0) { warn.style.display = 'none'; return; }
        if (!since) since = performance.now();
        warn.textContent = poseFresh() ? 'Volte à posição inicial e mantenha a cabeça parada' : 'Rosto não detectado: olhe para a câmera';
        warn.style.display = 'block';
        if (poseFresh() && performance.now() - since > 12000) { post({ type: 'setRef' }); await sleep(300); since = 0; } // aceita a nova postura
        await sleep(200);
      }
    };

    const collectPoint = async (id, px, py, isVal, first, color) => {
      for (let attempt = 0; attempt <= MAX_RETRY; attempt++) {
        await waitPose();
        if (stale()) return false;
        place(px, py, color);
        await sleep(first && attempt === 0 ? SETTLE + 450 : SETTLE);
        if (stale()) return false;
        const [tx, ty] = vToScr(innerWidth * px / 100, innerHeight * py / 100);
        post({ type: 'cal:start', id, tx, ty, val: isVal });
        await sleep(COLLECT);
        post({ type: 'cal:stop' });
        const r = await waitMsg('cal:group', 2500);
        if (stale()) return false;
        if (r && r.used >= 6) return true;
      }
      return true; // ponto falhou: segue em frente (o ajuste tolera pontos faltando)
    };

    for (let i = 0; i < train.length; i++) {
      if (stale()) return;
      title.textContent = `Calibração ${i + 1}/${total}`;
      await collectPoint('t' + i, train[i][0], train[i][1], false, i === 0, '#22d3ee');
      bar.style.width = (++done / total * 100) + '%';
    }
    for (let i = 0; i < val.length; i++) {
      if (stale()) return;
      title.textContent = `Verificação ${train.length + i + 1}/${total}`;
      sub.textContent = 'Mais alguns pontos para medir a precisão. Continue olhando fixamente.';
      await collectPoint('v' + i, val[i][0], val[i][1], true, false, '#4ade80');
      bar.style.width = (++done / total * 100) + '%';
    }
    if (stale()) return;

    // ---- 3) Ajuste
    dotC.style.display = 'none'; warn.style.display = 'none';
    title.textContent = 'Calculando…';
    sub.textContent = 'Escolhendo o melhor modelo para o seu olhar.';
    post({ type: 'cal:fit' });
    const res = await waitMsg('cal:result', 20000);
    if (stale()) return;
    if (!res || !res.ok) {
      endCalibration(false, null, 'Não foi possível calibrar' + (res && res.error ? ' (' + res.error + ')' : '') + '. Melhore a luz, centralize o rosto e tente de novo.');
      return;
    }

    // ---- 4) Resumo visual (alvo verde, previsão azul)
    finalRes = res; // a partir daqui o modelo já está salvo: Esc/Continuar apenas fecham o resumo
    const err = Math.round(res.err), pct = res.err / screen.width * 100;
    const label = pct < 3.5 ? 'Excelente' : pct < 6 ? 'Boa' : pct < 10 ? 'Razoável' : 'Fraca';
    title.textContent = `Calibração concluída: precisão ${label}`;
    sub.textContent = `Erro médio na verificação: ~${err}px (${pct.toFixed(1).replace('.', ',')}% da largura da tela).` +
      (pct >= 10 ? ' Melhore a luz, aproxime-se da câmera e recalibre.' : '');
    msg.style.top = '12%';
    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('style', 'position:absolute;inset:0;width:100%;height:100%;pointer-events:none');
    (res.points || []).forEach((p) => {
      const [tx, ty] = scrToV(p.tx, p.ty), [qx, qy] = scrToV(p.px, p.py);
      const ln = document.createElementNS(NS, 'line');
      ln.setAttribute('x1', tx); ln.setAttribute('y1', ty); ln.setAttribute('x2', qx); ln.setAttribute('y2', qy);
      ln.setAttribute('stroke', '#94a3b8'); ln.setAttribute('stroke-width', '2'); svg.appendChild(ln);
      const c1 = document.createElementNS(NS, 'circle'); c1.setAttribute('cx', tx); c1.setAttribute('cy', ty); c1.setAttribute('r', 11);
      c1.setAttribute('fill', 'none'); c1.setAttribute('stroke', '#4ade80'); c1.setAttribute('stroke-width', '3'); svg.appendChild(c1);
      const c2 = document.createElementNS(NS, 'circle'); c2.setAttribute('cx', qx); c2.setAttribute('cy', qy); c2.setAttribute('r', 6);
      c2.setAttribute('fill', '#22d3ee'); svg.appendChild(c2);
    });
    calibBox.appendChild(svg);
    cancel.textContent = 'Continuar (Esc)';
    await sleep(5500);
    if (stale()) return;
    endCalibration(true, res);
  }

  function startCalibration() {
    if (!ready) { pendingCalibrate = true; return; }
    pendingCalibrate = false;
    runCalibration();
  }

  function endCalibration(ok, res, failText) {
    if (!ok && finalRes) { ok = true; res = finalRes; }
    finalRes = null;
    calibAbort = true;
    const was = calibrating;
    calibrating = false;
    if (was && !ok) post({ type: 'cal:cancel' });
    post({ type: 'poseStream', on: false });
    if (calibBox) { calibBox.style.display = 'none'; calibBox.textContent = ''; }
    hasGaze = false; oneEuro.reset();
    if (ok) {
      const err = res && res.err ? Math.round(res.err) : null;
      chrome.storage.local.set({ calibrated: true, calibErr: err });
      S.calibErr = err; updateRadius();
      say('Calibração concluída! Olhe fixo para clicar.', 3500);
    } else {
      say(failText || 'Calibração cancelada.', failText ? 8000 : 2000);
    }
    dwellStart = performance.now();
  }

  function onPort(e) {
    const m = e.data;
    if (!m) return;
    if (waiters[m.type]) waiters[m.type](m);
    if (m.type === 'gaze') {
      if (!calibrating) onGaze(m.x, m.y);
    } else if (m.type === 'pose') {
      lastPose = { ...m, t: performance.now() };
      // Monitor de postura: avisa se a cabeça se afastou muito da posição da calibração.
      if (!calibrating && ready) {
        driftCount = m.drift > 1.8 ? driftCount + 1 : 0;
        if (driftCount >= 4 && performance.now() - lastDriftWarn > 60000) {
          lastDriftWarn = performance.now(); driftCount = 0;
          say('Sua posição mudou: volte à posição da calibração ou recalibre para manter a precisão.', 6000);
        }
      }
    } else if (m.type === 'noface') {
      if (ready && !calibrating) { say('Rosto não detectado: olhe para a câmera.', 0); toastKind = 'noface'; }
    } else if (m.type === 'face') {
      if (toastKind === 'noface' && toast) { toast.style.display = 'none'; toastKind = ''; }
    } else if (m.type === 'ready') {
      ready = true;
      clearTimeout(startTimer);
      toast.style.display = 'none';
      if (!S.calibrated || !m.hasModel || pendingCalibrate) startCalibration();
      else say('Controle pelo olhar ativo (desative no ícone da extensão)', 2500);
    } else if (m.type === 'error') {
      console.error('[OlhoLivre]', m.name, m.message, m.stack);
      const cam = /NotAllowed|NotFound|Permission|NotReadable|Overconstrained/i.test(m.name || '');
      say(cam
        ? 'Sem acesso à câmera (' + m.name + '). Libere na aba que abriu e ative de novo.'
        : 'Erro ao iniciar o rastreamento: ' + (m.name || '') + ' ' + (m.message || '').slice(0, 120), 8000);
      if (cam) chrome.runtime.sendMessage({ type: 'openSetup' });
      stop();
      chrome.storage.local.set({ enabled: false });
    }
  }

  // ---------- Olhar ----------
  // (x,y): posição normalizada da TELA vinda do estimador. Convertida para a janela e suavizada (One-Euro).
  function onGaze(nx, ny) {
    let [x, y] = scrToV(nx, ny);
    x = Math.max(0, Math.min(innerWidth, x));
    y = Math.max(0, Math.min(innerHeight, y));
    const [fx, fy] = oneEuro.f(x, y, performance.now());
    if (!hasGaze) { sx = fx; sy = fy; ax = fx; ay = fy; dwellStart = performance.now(); hasGaze = true; return; }
    sx = fx; sy = fy;
  }

  function tick(now) {
    raf = requestAnimationFrame(tick);
    if (!ready || calibrating || !hasGaze) return;

    if (S.showCursor) {
      dot.style.display = 'block';
      dot.style.transform = `translate(${sx}px,${sy}px)`;
    }

    // Rolagem pelas bordas
    const H = innerHeight;
    const top = H * EDGE, bottom = H * (1 - EDGE);
    let inEdge = false;
    if (S.scrollEnabled && (sy < top || sy > bottom)) {
      inEdge = true;
      if (!edgeSince) edgeSince = now;
      if (now - edgeSince > EDGE_DELAY) {
        const strength = sy < top ? -(top - sy) / top : (sy - bottom) / (H - bottom);
        scrollAt(sx, Math.sign(strength) * S.scrollSpeed * (0.4 + Math.abs(strength) * 1.6));
      }
    } else edgeSince = 0;

    // Clique por permanência
    if (inEdge) { ring.style.display = 'none'; ax = sx; ay = sy; dwellStart = now; return; }
    if (Math.hypot(sx - ax, sy - ay) > dwellRadius) { ax = sx; ay = sy; dwellStart = now; }
    const p = Math.max(0, (now - dwellStart) / S.dwellMs);
    if (p > 0.08 && S.showCursor) {
      ring.style.display = 'block';
      ring.style.transform = `translate(${sx}px,${sy}px)`;
      ring.style.background = `conic-gradient(#22d3ee ${Math.min(p, 1) * 360}deg, rgba(255,255,255,.18) 0)`;
    } else ring.style.display = 'none';
    if (p >= 1) {
      gazeClick(sx, sy);
      dwellStart = now + 900; // pausa curta após clicar
      ax = sx; ay = sy;
    }
  }

  function scrollAt(x, dy) {
    let el = document.elementFromPoint(Math.min(x, innerWidth - 1), innerHeight / 2);
    while (el && el !== document.documentElement) {
      const cs = getComputedStyle(el);
      if (/(auto|scroll)/.test(cs.overflowY) && el.scrollHeight > el.clientHeight + 1) {
        const before = el.scrollTop;
        el.scrollTop += dy;
        if (el.scrollTop !== before) return;
      }
      el = el.parentElement;
    }
    window.scrollBy(0, dy);
  }

  function gazeClick(x, y) {
    const el = document.elementFromPoint(x, y);
    if (!el || el.tagName === 'IFRAME') return;
    const o = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, button: 0 };
    el.dispatchEvent(new PointerEvent('pointerdown', o));
    el.dispatchEvent(new MouseEvent('mousedown', o));
    const focusable = el.closest('a,button,input,textarea,select,[contenteditable],[tabindex]');
    if (focusable && focusable.focus) focusable.focus({ preventScroll: true });
    el.dispatchEvent(new PointerEvent('pointerup', o));
    el.dispatchEvent(new MouseEvent('mouseup', o));
    el.dispatchEvent(new MouseEvent('click', o));
    flash();
  }

  function flash() {
    ring.style.display = 'block';
    ring.style.background = '#4ade80';
    setTimeout(() => (ring.style.display = 'none'), 180);
  }

  // ---------- Eventos ----------
  // Cliques reais do mouse continuam treinando o modelo (melhora a precisão com o uso).
  document.addEventListener('click', (e) => {
    if (e.isTrusted && ready && !calibrating) normTrain(e.clientX, e.clientY);
  }, true);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && calibrating) endCalibration(false);
  }, true);

  chrome.runtime.onMessage.addListener((m) => {
    if (m && m.to === 'tab' && active) onPort({ data: m });
  });

  document.addEventListener('visibilitychange', sync);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    for (const k in changes) S[k] = changes[k].newValue;
    if (changes.calibErr) updateRadius();
    if (changes.calibrateNonce && changes.calibrateNonce.newValue !== lastCalibNonce) {
      lastCalibNonce = changes.calibrateNonce.newValue;
      if (document.visibilityState === 'visible') { pendingCalibrate = true; sync(); if (ready) startCalibration(); }
    }
    if (changes.resetNonce && changes.resetNonce.newValue !== lastResetNonce) {
      lastResetNonce = changes.resetNonce.newValue;
      post({ type: 'reset' });
    }
    sync();
  });

  chrome.storage.local.get(null, (items) => {
    S = { ...DEFAULTS, ...items };
    updateRadius();
    lastCalibNonce = items.calibrateNonce;
    lastResetNonce = items.resetNonce;
    sync();
  });
})();
