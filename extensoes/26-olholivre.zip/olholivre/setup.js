const status = document.getElementById('status');
document.getElementById('btn').addEventListener('click', async () => {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    stream.getTracks().forEach((t) => t.stop());
    status.className = 'ok';
    status.textContent = '✔ Câmera liberada! Pode fechar esta aba e ativar a extensão pelo ícone 👁️ na barra do Chrome.';
  } catch (e) {
    status.className = 'err';
    status.textContent = '✖ Não foi possível acessar a câmera: ' + e.name +
      '. Verifique o ícone de câmera na barra de endereços e permita o acesso.';
  }
});

chrome.commands.getAll((cmds) => {
  const t = cmds.find((c) => c.name === 'toggle-gaze');
  const el = document.getElementById('sc');
  if (el) el.textContent = t && t.shortcut ? t.shortcut.replace('Command','⌘').replace('Shift','⇧').replace('MacCtrl','⌃').replace('Ctrl','⌃') : '(defina em chrome://extensions/shortcuts)';
});
