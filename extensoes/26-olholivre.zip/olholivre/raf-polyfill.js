// O documento offscreen não é renderizado, então requestAnimationFrame não dispara de forma contínua
// e o laço do WebGazer/TensorFlow trava. Substituímos por um timer (~30 fps).
(() => {
  let id = 0;
  const timers = new Map();
  window.requestAnimationFrame = (cb) => {
    const h = ++id;
    timers.set(h, setTimeout(() => { timers.delete(h); cb(performance.now()); }, 33));
    return h;
  };
  window.cancelAnimationFrame = (h) => { clearTimeout(timers.get(h)); timers.delete(h); };
})();
