// Documento offscreen da extensão: a câmera, o FaceMesh (WebGazer) e o estimador de olhar rodam aqui.
// O WebGazer fornece só o vídeo, os landmarks (com íris) e os pixels dos olhos; a regressão é a nossa (gazecore.js):
// íris + pose da cabeça + pixels, com seleção do modelo por validação cruzada e correção contínua por cliques.
// Comunicação: apenas chrome.runtime (coordenadas normalizadas da TELA, 0..1). O service worker repassa 'to:tab'.
(() => {
  const GC = self.GazeCore;
  const STORE = 'olholivre.model.v2';
  let started = false, ready = false, wg = null;
  let lastSeen = Date.now();
  let scr = { w: screen.width || 1440, h: screen.height || 900 };

  // ---- estado do estimador
  let model = null, groups = [], ref = null;
  let lastFrame = null, faceOk = true, lastFaceT = performance.now();
  let calibrating = false, calGroups = [], collector = null, collectMeta = null;
  let poseStream = false, lastPoseSent = 0, refitTimer = 0;
  const poseBuf = [], earHist = [];
  let sawIris = false;

  window.alert = () => {};
  const send = (m) => { try { chrome.runtime.sendMessage({ to: 'tab', ...m }, () => void chrome.runtime.lastError); } catch (e) {} };
  const report = (name, message, stack) => send({ type: 'error', name, message: String(message), stack: String(stack || '') });
  window.addEventListener('error', (e) => report('ScriptError', e.message, e.error && e.error.stack));
  window.addEventListener('unhandledrejection', (e) =>
    report((e.reason && e.reason.name) || 'Rejection', (e.reason && e.reason.message) || e.reason, e.reason && e.reason.stack));

  // Sem sinal de vida da aba por 30 s: fecha o documento (apaga a luz da câmera).
  setInterval(() => {
    if (Date.now() - lastSeen > 30000) chrome.runtime.sendMessage({ type: 'closeCamera' }, () => void chrome.runtime.lastError);
    if (ready && faceOk && performance.now() - lastFaceT > 700) { faceOk = false; send({ type: 'noface' }); }
  }, 300);

  // ---------------------------------------------------------------- persistência
  function save() {
    try {
      if (!model) return;
      localStorage.setItem(STORE, JSON.stringify({ v: 2, scr, model, ref, groups: GC.packGroups(groups) }));
    } catch (e) { console.warn('[OlhoLivre] não salvou modelo', e); }
  }
  function load() {
    try {
      const d = JSON.parse(localStorage.getItem(STORE) || 'null');
      if (!d || d.v !== 2 || !d.model) return;
      if (Math.abs(d.scr.w - scr.w) > 1 || Math.abs(d.scr.h - scr.h) > 1) return; // outra tela/zoom: recalibrar
      model = d.model; ref = d.ref || null; groups = d.groups || [];
    } catch (e) { model = null; }
  }

  // ---------------------------------------------------------------- quadro a quadro
  const pctl = (arr, q) => { const b = [...arr].sort((x, y) => x - y); return b[Math.min(b.length - 1, Math.floor(q * b.length))]; };
  function driftOf(g) {
    if (!ref || !g) return 0;
    return Math.max(Math.abs(g[7] - ref.cx) / 0.07, Math.abs(g[8] - ref.cy) / 0.07, Math.abs(g[9] - ref.ls) / 0.08,
      Math.abs(g[4] - ref.yaw) / 0.10, Math.abs(g[5] - ref.pitch) / 0.10, Math.abs(g[6] - ref.roll) / 0.15);
  }
  function brightness(eyes) {
    try {
      const d = eyes.left.patch.data; let s = 0, n = 0;
      for (let i = 0; i < d.length; i += 16) { s += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]; n++; }
      return n ? s / n : 0;
    } catch (e) { return 0; }
  }

  // Chamado pelo WebGazer a cada quadro (é o "predict" da nossa regressão).
  function onFrame(eyes) {
    const now = performance.now();
    if (!eyes) return null; // sem rosto: o temporizador acima avisa
    lastFaceT = now;
    if (!faceOk) { faceOk = true; send({ type: 'face' }); }

    let g = null;
    try {
      const cv = wg.getVideoElementCanvas();
      g = GC.extractGeometry(wg.getTracker().getPositions(), cv.width, cv.height);
    } catch (e) { g = null; }
    if (g) sawIris = true;
    let px = null;
    try { px = wg.util.getEyeFeats(eyes); } catch (e) { px = null; }
    const bright = brightness(eyes);

    let blink = false;
    if (g) {
      earHist.push(g[3]); if (earHist.length > 150) earHist.shift();
      blink = earHist.length > 20 && g[3] < 0.65 * pctl(earHist, 0.7);
    }
    const drift = driftOf(g);
    const frame = { t: now, g, px, blink, drift };
    lastFrame = frame;

    if (g) {
      poseBuf.push({ t: now, g }); if (poseBuf.length > 40) poseBuf.shift();
      const every = poseStream ? 200 : 1000;
      if (now - lastPoseSent > every && (poseStream || model)) {
        lastPoseSent = now;
        send({ type: 'pose', face: true, iris: true, cx: g[7], cy: g[8], s: Math.exp(g[9]), roll: g[6], yaw: g[4], pitch: g[5],
          bright, e: g[3], blink, drift });
      }
    } else if (now - lastPoseSent > 400 && poseStream) {
      lastPoseSent = now;
      send({ type: 'pose', face: true, iris: false, bright });
    }

    // coleta de amostras da calibração
    if (collector && !blink && px) {
      if (g && drift > 1.3) collectMeta.drifted++;
      else collector.push({ g, px });
    }

    if (calibrating || !model || blink) return null; // durante a piscada o cursor "segura" a última posição
    const p = GC.predict(model, g, px);
    return p ? { x: p.x * 1000, y: p.y * 1000, t: now } : null;
  }

  // Módulo de regressão do WebGazer (só adaptador: o aprendizado é nosso).
  function OlhoReg() {}
  OlhoReg.prototype.init = function () {};
  OlhoReg.prototype.addData = function () {};
  OlhoReg.prototype.setData = function () {};
  OlhoReg.prototype.getData = function () { return []; };
  OlhoReg.prototype.predict = function (eyes) { return onFrame(eyes); };
  OlhoReg.prototype.name = 'olho';

  // ---------------------------------------------------------------- calibração
  function median3(a, key) { return GC.median(a.map((s) => s.g[key])); }
  function setRef() {
    const recent = poseBuf.filter((s) => performance.now() - s.t < 1800);
    if (recent.length < 4) return false;
    ref = { yaw: median3(recent, 4), pitch: median3(recent, 5), roll: median3(recent, 6), cx: median3(recent, 7), cy: median3(recent, 8), ls: median3(recent, 9) };
    earHist.length = 0;
    return true;
  }

  function stopCollect() {
    const frames = collector || [], meta = collectMeta;
    collector = null; collectMeta = null;
    if (!meta) return { used: 0, raw: 0, drifted: 0 };
    const kept = GC.cleanFrames(frames);
    if (kept.length >= 6) {
      const D = kept[0].px.length, pm = new Array(D).fill(0);
      kept.forEach((f) => { for (let d = 0; d < D; d++) pm[d] += f.px[d] / kept.length; });
      calGroups.push({ id: meta.id, tx: meta.tx, ty: meta.ty, val: meta.val, gw: 1, frames: kept.map((f) => f.g), pm });
    }
    return { used: kept.length, raw: frames.length, drifted: meta.drifted };
  }

  function doFit() {
    const train = calGroups.filter((g) => !g.val), val = calGroups.filter((g) => g.val);
    if (train.length < 12) return { ok: false, error: 'poucos pontos válidos (' + train.length + ')' };
    let hold = null;
    if (val.length >= 3) {
      const mT = GC.fitModel(train, scr);
      if (mT) hold = GC.evalGroups(mT, val, scr);
    }
    const mF = GC.fitModel(calGroups, scr);
    if (!mF) return { ok: false, error: 'não foi possível ajustar o modelo' };
    model = mF; groups = calGroups.slice(); calGroups = [];
    if (!ref) setRef();
    save();
    return {
      ok: true,
      err: hold && hold.err != null ? hold.err : (mF.cv.err || null),
      holdout: !!(hold && hold.err != null),
      cv: mF.cv.err || null,
      points: hold ? hold.points : [],
      info: { map: mF.mapName, wG: mF.wG, wP: mF.wP, iris: !!mF.G, nTrain: train.length, nVal: val.length }
    };
  }

  function scheduleRefit() {
    clearTimeout(refitTimer);
    refitTimer = setTimeout(() => {
      try {
        if (!model || calibrating) return;
        const m = GC.fitModel(groups, scr, model.hp);
        if (m) { m.cv = model.cv; m.mapName = model.mapName; model = m; save(); }
      } catch (e) { console.warn('[OlhoLivre] refino falhou', e); }
    }, 1500);
  }

  // clique real do mouse: o usuário estava olhando ali -> amostra extra de alta confiança
  function liveTrain(x, y) {
    const f = lastFrame;
    if (!model || calibrating || !f || !f.g || f.blink || performance.now() - f.t > 250 || f.drift > 1.5) return;
    const live = groups.filter((g) => g.live);
    if (live.length >= 60) groups.splice(groups.indexOf(live[0]), 1);
    groups.push({ id: 'live' + Date.now(), live: true, gw: 0.35, tx: x, ty: y, frames: [f.g, f.g, f.g, f.g], pm: f.px });
    scheduleRefit();
  }

  // ---------------------------------------------------------------- mensagens da aba
  chrome.runtime.onMessage.addListener((m) => {
    if (!m || m.to !== 'offscreen') return;
    lastSeen = Date.now();
    switch (m.type) {
      case 'attach':
        if (m.scr && m.scr.w) { scr = m.scr; if (!model) load(); }
        if (ready) send({ type: 'ready', hasModel: !!model, iris: sawIris }); else start();
        break;
      case 'poseStream': poseStream = !!m.on; break;
      case 'setRef': send({ type: 'refSet', ok: setRef() }); break;
      case 'cal:begin':
        calibrating = true; calGroups = []; collector = null; collectMeta = null;
        if (m.scr && m.scr.w) scr = m.scr;
        break;
      case 'cal:start':
        collector = []; collectMeta = { id: m.id, tx: m.tx, ty: m.ty, val: !!m.val, drifted: 0 };
        break;
      case 'cal:stop': send({ type: 'cal:group', ...stopCollect() }); break;
      case 'cal:fit':
        try { send({ type: 'cal:result', ...doFit() }); }
        catch (e) { send({ type: 'cal:result', ok: false, error: String((e && e.message) || e) }); }
        calibrating = false; poseStream = false;
        break;
      case 'cal:cancel': calibrating = false; collector = null; collectMeta = null; calGroups = []; poseStream = false; break;
      case 'train': liveTrain(m.x, m.y); break;
      case 'reset':
        model = null; groups = []; calGroups = []; ref = null;
        try { localStorage.removeItem(STORE); } catch (e) {}
        break;
    }
  });

  async function start() {
    if (started) return;
    started = true;
    try {
      wg = window.webgazer;
      if (!wg) throw new Error('webgazer não carregou');
      if (!GC) throw new Error('gazecore não carregou');
      wg.util.bound = (p) => p; // o WebGazer limitaria ao tamanho (minúsculo) da janela offscreen
      wg.params.faceMeshSolutionPath = './mediapipe/face_mesh';
      wg.params.showGazeDot = false;
      // Mais resolução = íris mais precisa (o FaceMesh recorta os olhos a partir da imagem original).
      wg.params.camConstraints = { video: { width: { min: 320, ideal: 1280, max: 1920 }, height: { min: 240, ideal: 720, max: 1080 },
        frameRate: { ideal: 30 }, facingMode: 'user' } };
      wg.addRegressionModule('olho', OlhoReg);
      wg.setRegression('olho')
        .setGazeListener((d) => { if (d && d.x != null) send({ type: 'gaze', x: d.x / 1000, y: d.y / 1000, t: d.t }); })
        .applyKalmanFilter(false)
        .saveDataAcrossSessions(false);
      await wg.begin();
      wg.showVideoPreview(false).showPredictionPoints(false).showFaceOverlay(false).showFaceFeedbackBox(false);
      load();
      ready = true;
      send({ type: 'ready', hasModel: !!model, iris: sawIris });
    } catch (err) {
      started = false; // permite nova tentativa no próximo 'attach'
      send({ type: 'error', name: err && err.name, message: String((err && err.message) || err), stack: String((err && err.stack) || '') });
    }
  }
})();
