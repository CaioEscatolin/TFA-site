// content.js — injetado em toda página (host_permissions <all_urls>).
// Cria o widget flutuante (aparece sozinho, sem precisar pesquisar nada
// antes), com botões de fechar/minimizar funcionais, e executa os
// comandos de voz. Comandos de nível de página são executados aqui
// diretamente; comandos de nível de navegador (abas/janelas/favoritos/
// histórico/downloads) são delegados ao background.js.

(function () {
  if (window.__tfa_widget_injected) return; // evita duplicar em re-injeções
  window.__tfa_widget_injected = true;

  // ─── ESTADO / CONFIG ───────────────────────────────────────────────────
  const state = {
    view: 'expanded', // 'collapsed' | 'expanded' | 'hidden'
    tab: 'voz',
    listening: false,
    pushMode: false,
    settings: { autostart: false, sound: true, transcript: true, numbers: true, sensitivity: 7, lang: 'pt-BR' }
  };

  chrome.storage.local.get('tfa_settings', (r) => {
    if (r.tfa_settings) Object.assign(state.settings, r.tfa_settings);
    langSel.value = state.settings.lang;
    toggleAutostart.classList.toggle('on', state.settings.autostart);
    toggleSound.classList.toggle('on', state.settings.sound);
    toggleTranscript.classList.toggle('on', state.settings.transcript);
    toggleNumbers.classList.toggle('on', state.settings.numbers);
    sensitivity.value = state.settings.sensitivity;
    sensVal.textContent = state.settings.sensitivity;
    transcriptBox.style.display = state.settings.transcript ? '' : 'none';
    if (state.settings.autostart) startListening();
  });
  function saveSettings() { chrome.storage.local.set({ tfa_settings: state.settings }); }

  // ─── SHADOW DOM HOST ─────────────────────────────────────────────────────
  const host = document.createElement('div');
  host.id = 'tfa-voice-widget-host';
  host.style.cssText = 'all:initial;position:fixed;bottom:20px;right:20px;z-index:2147483647;';
  document.documentElement.appendChild(host);
  const root = host.attachShadow({ mode: 'open' });

  root.innerHTML = `
  <style>
    :host { all: initial; }
    * { box-sizing: border-box; margin:0; padding:0; font-family:'Segoe UI',sans-serif; }
    .bubble {
      width:52px; height:52px; border-radius:50%; background:#1a73e8; color:#fff;
      display:flex; align-items:center; justify-content:center; font-size:24px;
      cursor:pointer; box-shadow:0 4px 14px rgba(0,0,0,0.25); border:none;
    }
    .bubble.listening { background:#ea4335; animation:pulse 1.2s infinite; }
    @keyframes pulse { 0%,100%{box-shadow:0 4px 14px rgba(234,67,53,.4);} 50%{box-shadow:0 4px 26px rgba(234,67,53,.7);} }
    .panel { width:320px; max-height:520px; background:#f0f4ff; border-radius:14px; padding:14px;
      box-shadow:0 6px 24px rgba(0,0,0,0.25); display:none; flex-direction:column; }
    .panel.show { display:flex; }
    .bubble { cursor: grab; }
    .bubble.hide { display:none; }
    .header { cursor: grab; }
    .header { display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; }
    .header h1 { font-size:15px; color:#1a73e8; display:flex; gap:6px; align-items:center; }
    .win-btns { display:flex; gap:6px; }
    .win-btn { width:22px; height:22px; border-radius:6px; border:none; background:#e8f0fe; color:#1a73e8;
      cursor:pointer; font-size:13px; line-height:1; display:flex; align-items:center; justify-content:center; }
    .win-btn:hover { background:#d3e3fd; }
    .win-btn.close:hover { background:#fbdada; color:#c5221f; }
    .tabs { display:flex; gap:5px; margin-bottom:10px; }
    .tab { flex:1; padding:6px 0; border-radius:20px; border:none; cursor:pointer; font-size:11px; font-weight:600;
      background:#fff; color:#555; box-shadow:0 1px 3px rgba(0,0,0,.1); }
    .tab.active { background:#1a73e8; color:#fff; }
    .card { background:#fff; border-radius:12px; padding:12px; overflow-y:auto; max-height:400px; }
    .panelv { display:none; } .panelv.active { display:block; }
    label { font-size:12px; color:#444; display:block; margin-bottom:5px; }
    select, .search-box { width:100%; padding:7px 9px; border-radius:8px; border:1.5px solid #d0d9f0; font-size:12px;
      background:#f8faff; margin-bottom:10px; outline:none; }
    .status-row { display:flex; align-items:center; gap:8px; margin-bottom:10px; }
    .status-dot { width:9px; height:9px; border-radius:50%; background:#ccc; }
    .status-dot.on { background:#34a853; box-shadow:0 0 6px #34a85388; }
    .status-text { font-size:12px; color:#555; }
    .btn-primary { width:100%; padding:10px; border-radius:10px; border:none; background:#1a73e8; color:#fff;
      font-size:13px; font-weight:700; cursor:pointer; margin-bottom:8px; }
    .btn-primary.listening { background:#ea4335; }
    .mode-row { display:flex; gap:6px; margin-bottom:10px; }
    .btn-mode { flex:1; padding:6px; border-radius:8px; border:1.5px solid #d0d9f0; background:#f8faff;
      font-size:11px; font-weight:600; color:#555; cursor:pointer; }
    .btn-mode.active { background:#e8f0fe; border-color:#1a73e8; color:#1a73e8; }
    .transcript-box { background:#f0f4ff; border-radius:8px; padding:9px; font-size:11px; color:#555;
      min-height:40px; border:1px dashed #c5d3f0; }
    .transcript-box span { color:#1a73e8; font-weight:600; }
    .cmd-group { margin-bottom:10px; }
    .cmd-group-title { font-size:10px; font-weight:700; color:#1a73e8; text-transform:uppercase;
      border-bottom:1.5px solid #e8f0fe; padding-bottom:3px; margin-bottom:5px; }
    .command-item { display:flex; gap:6px; padding:5px 7px; border-radius:6px; background:#f8faff;
      margin-bottom:3px; font-size:11px; }
    .command-item .cmd { color:#1a73e8; font-weight:700; min-width:100px; flex-shrink:0; }
    .command-item .desc { color:#666; }
    .toggle-row { display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; }
    .toggle-label { font-size:12px; color:#444; }
    .toggle { width:36px; height:20px; background:#ccc; border-radius:10px; position:relative; cursor:pointer;
      border:none; }
    .toggle.on { background:#1a73e8; }
    .toggle::after { content:''; position:absolute; top:2px; left:2px; width:16px; height:16px; border-radius:50%;
      background:#fff; transition:.2s; }
    .toggle.on::after { transform:translateX(16px); }
    input[type=range] { width:100%; accent-color:#1a73e8; }
    .slider-val { text-align:right; font-size:11px; color:#888; }
  </style>

  <button class="bubble" id="bubble" aria-label="Abrir controle de voz">
    <svg viewBox="0 0 24 24" width="24" height="24" fill="#fff"><path d="M19.439 7.85c-.049.322.059.648.289.878l1.568 1.568c.47.47.706 1.087.706 1.704s-.235 1.233-.706 1.704l-1.611 1.611a.98.98 0 0 1-.837.276c-.47-.07-.802-.48-.968-.925a2.501 2.501 0 1 0-3.214 3.214c.446.166.855.497.925.968a.979.979 0 0 1-.276.837l-1.61 1.61a2.404 2.404 0 0 1-1.705.707 2.402 2.402 0 0 1-1.704-.706l-1.568-1.568a1.026 1.026 0 0 0-.877-.29c-.493.074-.84.504-1.02.968a2.5 2.5 0 1 1-3.237-3.237c.464-.18.894-.527.967-1.02a1.026 1.026 0 0 0-.289-.877l-1.568-1.568A2.402 2.402 0 0 1 1.998 12c0-.617.236-1.234.706-1.704L4.23 8.77c.24-.24.581-.353.917-.303.515.077.877.528 1.073 1.01a2.5 2.5 0 1 0 3.259-3.259c-.482-.196-.933-.558-1.01-1.073-.05-.336.062-.676.303-.917l1.525-1.525A2.402 2.402 0 0 1 12 1.998c.617 0 1.234.236 1.704.706l1.568 1.568c.23.23.556.338.877.29.493-.074.84-.504 1.02-.968a2.5 2.5 0 1 1 3.237 3.237c-.464.18-.894.527-.967 1.02Z"/></svg>
  </button>
  <div class="panel" id="panel">
    <div class="header">
      <h1>🎙️ Tech for all</h1>
      <div class="win-btns">
        <button class="win-btn" id="btn-min" title="Minimizar">–</button>
        <button class="win-btn close" id="btn-close" title="Fechar">×</button>
      </div>
    </div>
    <div class="tabs">
      <button class="tab active" data-tab="voz">🎤 Voz</button>
      <button class="tab" data-tab="comandos">📋 Comandos</button>
      <button class="tab" data-tab="config">⚙️ Config.</button>
    </div>
    <div class="card">
      <div class="panelv active" id="panel-voz">
        <label>Idioma:</label>
        <select id="lang-select">
          <option value="pt-BR">🇧🇷 Português (Brasil)</option>
          <option value="en-US">🇺🇸 English (US)</option>
          <option value="es-ES">🇪🇸 Español</option>
        </select>
        <label>Modo de escuta:</label>
        <div class="mode-row">
          <button class="btn-mode active" id="mode-continuous">🔄 Contínuo</button>
          <button class="btn-mode" id="mode-push">⌨️ Ctrl para falar</button>
        </div>
        <div class="status-row">
          <div class="status-dot" id="status-dot"></div>
          <span class="status-text" id="status-text">Microfone inativo</span>
        </div>
        <button class="btn-primary" id="btn-mic">🎤 Iniciar Escuta</button>
        <div class="transcript-box" id="transcript"><span>Aguardando comando de voz...</span></div>
      </div>
      <div class="panelv" id="panel-comandos">
        <input class="search-box" id="cmd-search" placeholder="🔍 Filtrar comandos..." />
        <div id="cmd-list"></div>
      </div>
      <div class="panelv" id="panel-config">
        <div class="toggle-row"><span class="toggle-label">Ativar ao abrir a página</span><button class="toggle" id="toggle-autostart"></button></div>
        <div class="toggle-row"><span class="toggle-label">Feedback sonoro</span><button class="toggle on" id="toggle-sound"></button></div>
        <div class="toggle-row"><span class="toggle-label">Mostrar transcrição</span><button class="toggle on" id="toggle-transcript"></button></div>
        <div class="toggle-row"><span class="toggle-label">Mostrar numeração ao clicar</span><button class="toggle on" id="toggle-numbers"></button></div>
        <div class="slider-row">
          <label>Sensibilidade do microfone:</label>
          <input type="range" id="sensitivity" min="1" max="10" value="7" />
          <div class="slider-val" id="sens-val">7</div>
        </div>
      </div>
    </div>
  </div>`;

  // ─── REFS ────────────────────────────────────────────────────────────────
  const bubble = root.getElementById('bubble');
  const panel = root.getElementById('panel');
  const btnMin = root.getElementById('btn-min');
  const btnClose = root.getElementById('btn-close');
  const btnMic = root.getElementById('btn-mic');
  const dot = root.getElementById('status-dot');
  const statusTx = root.getElementById('status-text');
  const transcriptBox = root.getElementById('transcript');
  const langSel = root.getElementById('lang-select');
  const modeCont = root.getElementById('mode-continuous');
  const modePush = root.getElementById('mode-push');
  const toggleAutostart = root.getElementById('toggle-autostart');
  const toggleSound = root.getElementById('toggle-sound');
  const toggleTranscript = root.getElementById('toggle-transcript');
  const toggleNumbers = root.getElementById('toggle-numbers');
  const sensitivity = root.getElementById('sensitivity');
  const sensVal = root.getElementById('sens-val');

  // ─── JANELA: mostrar / minimizar / fechar ───────────────────────────────
  function applyView() {
    bubble.classList.toggle('hide', state.view === 'hidden');
    panel.classList.toggle('show', state.view === 'expanded');
    if (state.view !== 'expanded' && state.view !== 'hidden') bubble.classList.remove('hide');
  }
  bubble.addEventListener('click', () => { if (dragMoved) { dragMoved = false; return; } state.view = 'expanded'; applyView(); });
  btnMin.addEventListener('click', () => { state.view = 'collapsed'; applyView(); });
  btnClose.addEventListener('click', () => { state.view = 'hidden'; applyView(); });
  applyView();

  // ─── ARRASTAR (mover o widget pela tela) ────────────────────────────────
  let dragMoved = false;
  function makeDraggable(handle) {
    let dragging = false, startX = 0, startY = 0, origLeft = 0, origTop = 0;
    handle.addEventListener('pointerdown', (e) => {
      if (e.target.closest && e.target.closest('.win-btn')) return; // não arrasta ao clicar em fechar/minimizar
      dragging = true; dragMoved = false;
      const rect = host.getBoundingClientRect();
      origLeft = rect.left; origTop = rect.top;
      host.style.left = origLeft + 'px';
      host.style.top = origTop + 'px';
      host.style.right = 'auto';
      host.style.bottom = 'auto';
      startX = e.clientX; startY = e.clientY;
      handle.setPointerCapture(e.pointerId);
      handle.style.cursor = 'grabbing';
    });
    handle.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const dx = e.clientX - startX, dy = e.clientY - startY;
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) dragMoved = true;
      const maxLeft = Math.max(0, window.innerWidth - host.offsetWidth);
      const maxTop = Math.max(0, window.innerHeight - host.offsetHeight);
      host.style.left = Math.min(Math.max(0, origLeft + dx), maxLeft) + 'px';
      host.style.top = Math.min(Math.max(0, origTop + dy), maxTop) + 'px';
    });
    const stop = () => { dragging = false; handle.style.cursor = 'grab'; };
    handle.addEventListener('pointerup', stop);
    handle.addEventListener('pointercancel', stop);
  }
  makeDraggable(bubble);
  makeDraggable(root.querySelector('.header'));

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'TOGGLE_WIDGET') {
      state.view = (state.view === 'hidden') ? 'expanded' : 'hidden';
      applyView();
    }
  });

  // ─── TABS ────────────────────────────────────────────────────────────────
  root.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      root.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      root.querySelectorAll('.panelv').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      root.getElementById('panel-' + tab.dataset.tab).classList.add('active');
    });
  });

  // ─── TOGGLES / SLIDER (persistidos) ─────────────────────────────────────
  toggleAutostart.addEventListener('click', () => { toggleAutostart.classList.toggle('on'); state.settings.autostart = toggleAutostart.classList.contains('on'); saveSettings(); });
  toggleSound.addEventListener('click', () => { toggleSound.classList.toggle('on'); state.settings.sound = toggleSound.classList.contains('on'); saveSettings(); });
  toggleTranscript.addEventListener('click', () => {
    toggleTranscript.classList.toggle('on');
    state.settings.transcript = toggleTranscript.classList.contains('on');
    transcriptBox.style.display = state.settings.transcript ? '' : 'none';
    saveSettings();
  });
  toggleNumbers.addEventListener('click', () => { toggleNumbers.classList.toggle('on'); state.settings.numbers = toggleNumbers.classList.contains('on'); saveSettings(); });
  sensitivity.addEventListener('input', () => { sensVal.textContent = sensitivity.value; state.settings.sensitivity = +sensitivity.value; saveSettings(); });
  langSel.addEventListener('change', () => { state.settings.lang = langSel.value; saveSettings(); });

  // ─── FEEDBACK SONORO ─────────────────────────────────────────────────────
  function beep() {
    if (!state.settings.sound) return;
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const o = ctx.createOscillator(); const g = ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.frequency.value = 880; g.gain.value = 0.05;
      o.start(); o.stop(ctx.currentTime + 0.08);
    } catch (e) { /* ignora se contexto de áudio bloqueado */ }
  }

  // ─── COMANDOS (lista exibida na aba Comandos) ───────────────────────────
  const COMMANDS = [
    { group: '🧭 Navegação', cmd: '"rolar baixo"', desc: 'Rola a página para baixo' },
    { group: '🧭 Navegação', cmd: '"rolar cima"', desc: 'Rola a página para cima' },
    { group: '🧭 Navegação', cmd: '"rolar direita"', desc: 'Rola a página para a direita' },
    { group: '🧭 Navegação', cmd: '"rolar esquerda"', desc: 'Rola a página para a esquerda' },
    { group: '🧭 Navegação', cmd: '"ir ao topo"', desc: 'Vai ao topo da página' },
    { group: '🧭 Navegação', cmd: '"ir ao final"', desc: 'Vai ao final da página' },
    { group: '🧭 Navegação', cmd: '"voltar"', desc: 'Volta à página anterior' },
    { group: '🧭 Navegação', cmd: '"avançar"', desc: 'Avança à página seguinte' },
    { group: '🧭 Navegação', cmd: '"recarregar"', desc: 'Recarrega a página atual' },
    { group: '🧭 Navegação', cmd: '"parar carregamento"', desc: 'Para o carregamento da página' },
    { group: '🧭 Navegação', cmd: '"abrir [site]"', desc: 'Abre um site. Ex: "abrir youtube"' },
    { group: '🧭 Navegação', cmd: '"ir para [site]"', desc: 'Navega para um endereço' },
    { group: '🧭 Navegação', cmd: '"pesquisar [termo]"', desc: 'Pesquisa no Google' },
    { group: '🧭 Navegação', cmd: '"encontrar [texto]"', desc: 'Busca texto na página atual' },
    { group: '🖱️ Clique & Seleção', cmd: '"clicar"', desc: 'Mostra números nos elementos clicáveis' },
    { group: '🖱️ Clique & Seleção', cmd: '"[número]"', desc: 'Clica no elemento com aquele número' },
    { group: '🖱️ Clique & Seleção', cmd: '"selecionar tudo"', desc: 'Seleciona todo o conteúdo (Ctrl+A)' },
    { group: '🖱️ Clique & Seleção', cmd: '"foco próximo"', desc: 'Move o foco para o próximo elemento' },
    { group: '🖱️ Clique & Seleção', cmd: '"foco anterior"', desc: 'Move o foco para o elemento anterior' },
    { group: '🖱️ Clique & Seleção', cmd: '"pressionar enter"', desc: 'Simula a tecla Enter' },
    { group: '🖱️ Clique & Seleção', cmd: '"pressionar escape"', desc: 'Simula a tecla Escape' },
    { group: '🖱️ Clique & Seleção', cmd: '"pressionar tab"', desc: 'Simula a tecla Tab' },
    { group: '✏️ Formulários & Ditado', cmd: '"digitar [texto]"', desc: 'Digita o texto no campo ativo' },
    { group: '✏️ Formulários & Ditado', cmd: '"limpar campo"', desc: 'Apaga o conteúdo do campo ativo' },
    { group: '✏️ Formulários & Ditado', cmd: '"apagar palavra"', desc: 'Apaga a última palavra digitada' },
    { group: '✏️ Formulários & Ditado', cmd: '"copiar"', desc: 'Copia o conteúdo selecionado' },
    { group: '✏️ Formulários & Ditado', cmd: '"colar"', desc: 'Cola o conteúdo copiado' },
    { group: '✏️ Formulários & Ditado', cmd: '"recortar"', desc: 'Recorta o conteúdo selecionado' },
    { group: '✏️ Formulários & Ditado', cmd: '"desfazer"', desc: 'Desfaz a última ação' },
    { group: '✏️ Formulários & Ditado', cmd: '"refazer"', desc: 'Refaz a última ação' },
    { group: '✏️ Formulários & Ditado', cmd: '"nova linha"', desc: 'Insere uma quebra de linha' },
    { group: '🗂️ Abas', cmd: '"nova aba"', desc: 'Abre uma nova aba' },
    { group: '🗂️ Abas', cmd: '"fechar aba"', desc: 'Fecha a aba atual' },
    { group: '🗂️ Abas', cmd: '"restaurar aba"', desc: 'Reabre a última aba fechada' },
    { group: '🗂️ Abas', cmd: '"próxima aba"', desc: 'Vai para a próxima aba' },
    { group: '🗂️ Abas', cmd: '"aba anterior"', desc: 'Vai para a aba anterior' },
    { group: '🗂️ Abas', cmd: '"duplicar aba"', desc: 'Duplica a aba atual' },
    { group: '🗂️ Abas', cmd: '"fixar aba"', desc: 'Fixa/desfixa a aba atual' },
    { group: '🗂️ Abas', cmd: '"silenciar aba"', desc: 'Silencia/ativa o som da aba' },
    { group: '🗂️ Abas', cmd: '"aba [número]"', desc: 'Vai para a aba de número indicado' },
    { group: '⭐ Favoritos', cmd: '"adicionar favorito"', desc: 'Salva a página nos favoritos' },
    { group: '⭐ Favoritos', cmd: '"remover favorito"', desc: 'Remove a página dos favoritos' },
    { group: '⭐ Favoritos', cmd: '"abrir favoritos"', desc: 'Abre o gerenciador de favoritos' },
    { group: '🕓 Histórico', cmd: '"abrir histórico"', desc: 'Abre o histórico de navegação' },
    { group: '🕓 Histórico', cmd: '"limpar histórico"', desc: 'Abre opções para limpar histórico' },
    { group: '⬇️ Downloads', cmd: '"abrir downloads"', desc: 'Abre a página de downloads' },
    { group: '⬇️ Downloads', cmd: '"baixar página"', desc: 'Baixa a página atual' },
    { group: '🔍 Zoom & Visualização', cmd: '"aumentar zoom"', desc: 'Aumenta o zoom da página' },
    { group: '🔍 Zoom & Visualização', cmd: '"diminuir zoom"', desc: 'Diminui o zoom da página' },
    { group: '🔍 Zoom & Visualização', cmd: '"zoom normal"', desc: 'Restaura o zoom padrão' },
    { group: '🔍 Zoom & Visualização', cmd: '"tela cheia"', desc: 'Ativa/desativa tela cheia' },
    { group: '🔍 Zoom & Visualização', cmd: '"imprimir"', desc: 'Abre o diálogo de impressão' },
    { group: '🎬 Mídia', cmd: '"play" / "pausar"', desc: 'Inicia/pausa o vídeo ou áudio' },
    { group: '🎬 Mídia', cmd: '"parar vídeo"', desc: 'Para a reprodução de mídia' },
    { group: '🎬 Mídia', cmd: '"avançar vídeo"', desc: 'Avança 10 segundos no vídeo' },
    { group: '🎬 Mídia', cmd: '"voltar vídeo"', desc: 'Retrocede 10 segundos no vídeo' },
    { group: '🎬 Mídia', cmd: '"aumentar volume"', desc: 'Aumenta o volume' },
    { group: '🎬 Mídia', cmd: '"diminuir volume"', desc: 'Diminui o volume' },
    { group: '🎬 Mídia', cmd: '"silenciar"', desc: 'Silencia/ativa o áudio do vídeo' },
    { group: '🎬 Mídia', cmd: '"tela cheia vídeo"', desc: 'Coloca o vídeo em tela cheia' },
    { group: '🪟 Janela', cmd: '"nova janela"', desc: 'Abre uma nova janela do Chrome' },
    { group: '🪟 Janela', cmd: '"janela anônima"', desc: 'Abre uma janela anônima' },
    { group: '🪟 Janela', cmd: '"fechar janela"', desc: 'Fecha a janela atual' },
    { group: '❓ Ajuda', cmd: '"ajuda"', desc: 'Abre a aba de comandos disponíveis' },
  ];
  function renderCommands(filter = '') {
    const list = root.getElementById('cmd-list');
    const filtered = filter ? COMMANDS.filter(c => c.cmd.toLowerCase().includes(filter) || c.desc.toLowerCase().includes(filter)) : COMMANDS;
    const groups = {};
    filtered.forEach(c => { (groups[c.group] ||= []).push(c); });
    list.innerHTML = Object.keys(groups).length
      ? Object.entries(groups).map(([grp, cmds]) => `<div class="cmd-group"><div class="cmd-group-title">${grp}</div>` +
          cmds.map(c => `<div class="command-item"><span class="cmd">${c.cmd}</span><span class="desc">${c.desc}</span></div>`).join('') + `</div>`).join('')
      : '<div style="color:#aaa;font-size:12px;text-align:center;padding:16px 0">Nenhum comando encontrado</div>';
  }
  root.getElementById('cmd-search').addEventListener('input', e => renderCommands(e.target.value.toLowerCase()));
  renderCommands();

  // ─── RECONHECIMENTO DE VOZ ───────────────────────────────────────────────
  let recognition = null;
  modeCont.addEventListener('click', () => { state.pushMode = false; modeCont.classList.add('active'); modePush.classList.remove('active'); });
  modePush.addEventListener('click', () => { state.pushMode = true; modePush.classList.add('active'); modeCont.classList.remove('active'); });

  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { btnMic.textContent = '⚠️ Não suportado'; btnMic.disabled = true; transcriptBox.innerHTML = '<span>Este navegador não suporta reconhecimento de voz.</span>'; }

  function startListening() {
    if (!SR || state.listening) return;
    recognition = new SR();
    recognition.lang = langSel.value;
    recognition.continuous = !state.pushMode;
    recognition.interimResults = true;
    recognition.onstart = () => {
      state.listening = true;
      btnMic.textContent = '⏹ Parar Escuta';
      btnMic.classList.add('listening');
      bubble.classList.add('listening');
      dot.classList.add('on');
      statusTx.textContent = state.pushMode ? 'Segure Ctrl para falar...' : 'Ouvindo continuamente...';
      transcriptBox.innerHTML = '<span>Fale um comando...</span>';
    };
    recognition.onresult = (e) => {
      let final = '', interim = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript;
        e.results[i].isFinal ? final += t : interim += t;
      }
      if (state.settings.transcript) {
        transcriptBox.innerHTML = final ? `<span>✅ ${final}</span>` : `<em style="color:#aaa">${interim}</em>`;
      }
      if (final) {
        const cmd = final.trim().toLowerCase();
        beep();
        if (cmd.includes('ajuda') || cmd.includes('o que posso dizer')) {
          root.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
          root.querySelectorAll('.panelv').forEach(p => p.classList.remove('active'));
          root.querySelector('[data-tab="comandos"]').classList.add('active');
          root.getElementById('panel-comandos').classList.add('active');
          if (state.settings.transcript) transcriptBox.innerHTML = '<span>📋 Lista de comandos aberta!</span>';
          return;
        }
        runCommand(cmd);
      }
    };
    recognition.onerror = (e) => {
      if (e.error === 'no-speech' || e.error === 'aborted') return;
      transcriptBox.innerHTML = `<span style="color:#ea4335">Erro: ${e.error}</span>`;
      stopListening();
    };
    recognition.onend = () => { if (state.listening && !state.pushMode) { try { recognition.start(); } catch (e) { } } };
    try { recognition.start(); } catch (e) { }
  }
  function stopListening() {
    state.listening = false;
    if (recognition) { try { recognition.stop(); } catch (e) { } }
    btnMic.textContent = '🎤 Iniciar Escuta';
    btnMic.classList.remove('listening');
    bubble.classList.remove('listening');
    dot.classList.remove('on');
    statusTx.textContent = 'Microfone inativo';
  }
  btnMic.addEventListener('click', () => { state.listening ? stopListening() : startListening(); });
  document.addEventListener('keydown', e => { if (e.key === 'Control' && state.pushMode && !state.listening) startListening(); });
  document.addEventListener('keyup', e => { if (e.key === 'Control' && state.pushMode && state.listening) stopListening(); });

  // ─── EXECUÇÃO DE COMANDOS ────────────────────────────────────────────────
  function sendToBackground(cmd) { chrome.runtime.sendMessage({ type: 'EXECUTE_BG_COMMAND', cmd }); }

  function getClickable() {
    return Array.from(document.querySelectorAll('a,button,input,select,textarea,[role="button"],[onclick]'))
      .filter(el => !host.contains(el) && (() => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; })());
  }

  function setEditableText(el, txt, append) {
    if (!el) return;
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      el.value = append ? (el.value || '') + txt : txt;
      el.dispatchEvent(new Event('input', { bubbles: true }));
    } else if (el.isContentEditable) {
      document.execCommand('insertText', false, txt);
    }
  }

  function runCommand(cmd) {
    // ── Comandos de NAVEGADOR (delegados ao background.js) ─────────────────
    // Verificados ANTES do "abrir [site]" genérico para não confundir
    // "abrir favoritos/histórico/downloads" com um endereço de site.
    const BROWSER_PATTERNS = [
      'nova aba', 'duplicar aba', 'fechar aba', 'restaurar aba', 'próxima aba', 'aba anterior',
      'fixar aba', 'silenciar aba', 'adicionar favorito', 'remover favorito', 'abrir favoritos',
      'mostrar favoritos', 'limpar histórico', 'abrir histórico', 'abrir downloads', 'baixar página',
      'nova janela', 'janela anônima', 'fechar janela'
    ];
    if (BROWSER_PATTERNS.some(p => cmd.includes(p)) || /^aba \d+$/.test(cmd)) {
      return sendToBackground(cmd);
    }

    // ── NAVEGAÇÃO (executada diretamente na página) ────────────────────────
    if (cmd.includes('rolar baixo'))    return window.scrollBy({ top: 300, behavior: 'smooth' });
    if (cmd.includes('rolar cima'))     return window.scrollBy({ top: -300, behavior: 'smooth' });
    if (cmd.includes('rolar direita'))  return window.scrollBy({ left: 300, behavior: 'smooth' });
    if (cmd.includes('rolar esquerda')) return window.scrollBy({ left: -300, behavior: 'smooth' });
    if (cmd.includes('ir ao topo'))     return window.scrollTo({ top: 0, behavior: 'smooth' });
    if (cmd.includes('ir ao final'))    return window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    if (cmd.includes('recarregar'))     return location.reload();
    if (cmd.includes('parar carregamento')) return window.stop();
    if (cmd.includes('voltar') && !cmd.includes('vídeo'))  return history.back();
    if (cmd.includes('avançar') && !cmd.includes('vídeo')) return history.forward();

    if (cmd.startsWith('abrir ') || cmd.startsWith('ir para ')) {
      const site = cmd.replace(/^(abrir |ir para )/, '').trim().replace(/\s+/g, '');
      if (!site) return;
      location.href = site.includes('.') ? `https://${site}` : `https://www.${site}.com`;
      return;
    }
    if (cmd.startsWith('pesquisar ')) {
      location.href = `https://www.google.com/search?q=${encodeURIComponent(cmd.replace('pesquisar ', ''))}`;
      return;
    }
    if (cmd.startsWith('encontrar ')) return window.find(cmd.replace('encontrar ', ''));

    // ── CLIQUE COM NUMERAÇÃO ────────────────────────────────────────────────
    if (cmd === 'clicar') {
      document.querySelectorAll('.__hf_label').forEach(el => el.remove());
      const els = getClickable();
      if (!state.settings.numbers) return; // numeração desativada nas configs
      els.forEach((el, i) => {
        const r = el.getBoundingClientRect();
        const lbl = document.createElement('span');
        lbl.className = '__hf_label';
        lbl.textContent = i + 1;
        lbl.style.cssText = `position:fixed;top:${r.top}px;left:${r.left}px;background:#1a73e8;color:#fff;font-size:11px;font-weight:bold;padding:1px 5px;border-radius:4px;z-index:2147483647;pointer-events:none;`;
        document.body.appendChild(lbl);
      });
      setTimeout(() => document.querySelectorAll('.__hf_label').forEach(el => el.remove()), 5000);
      return;
    }
    const numMatch = cmd.match(/^(\d+)$/);
    if (numMatch) {
      const idx = parseInt(numMatch[1]) - 1;
      const els = getClickable();
      if (els[idx]) { els[idx].click(); els[idx].focus(); }
      return;
    }

    // ── TECLADO / FOCO ───────────────────────────────────────────────────────
    if (cmd.includes('selecionar tudo'))   return document.execCommand('selectAll');
    if (cmd.includes('pressionar enter'))  return document.activeElement?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
    if (cmd.includes('pressionar escape')) return document.activeElement?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    if (cmd.includes('pressionar tab'))    return document.activeElement?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', bubbles: true }));
    if (cmd.includes('foco próximo')) {
      const els = document.querySelectorAll('a,button,input,select,textarea');
      const i = Array.from(els).indexOf(document.activeElement);
      if (els[i + 1]) els[i + 1].focus();
      return;
    }
    if (cmd.includes('foco anterior')) {
      const els = document.querySelectorAll('a,button,input,select,textarea');
      const i = Array.from(els).indexOf(document.activeElement);
      if (els[i - 1]) els[i - 1].focus();
      return;
    }

    // ── FORMULÁRIOS & DITADO ──────────────────────────────────────────────────
    if (cmd.startsWith('digitar ')) return setEditableText(document.activeElement, cmd.replace('digitar ', ''), true);
    if (cmd.includes('limpar campo')) return setEditableText(document.activeElement, '', false);
    if (cmd.includes('apagar palavra')) {
      const el = document.activeElement;
      if (el && 'value' in el) { el.value = el.value.replace(/\s*\S+\s*$/, ''); el.dispatchEvent(new Event('input', { bubbles: true })); }
      return;
    }
    if (cmd.includes('nova linha')) {
      const el = document.activeElement;
      if (el && el.tagName === 'TEXTAREA') { el.value += '\n'; el.dispatchEvent(new Event('input', { bubbles: true })); }
      else if (el && el.isContentEditable) document.execCommand('insertLineBreak');
      return;
    }
    if (cmd.includes('copiar'))    return document.execCommand('copy');
    if (cmd.includes('colar'))     return document.execCommand('paste');
    if (cmd.includes('recortar'))  return document.execCommand('cut');
    if (cmd.includes('desfazer'))  return document.execCommand('undo');
    if (cmd.includes('refazer'))   return document.execCommand('redo');

    // ── ZOOM & VISUALIZAÇÃO ──────────────────────────────────────────────────
    if (cmd.includes('aumentar zoom')) return document.body.style.zoom = (parseFloat(document.body.style.zoom || 1) + 0.1).toFixed(1);
    if (cmd.includes('diminuir zoom')) return document.body.style.zoom = Math.max(0.3, parseFloat(document.body.style.zoom || 1) - 0.1).toFixed(1);
    if (cmd.includes('zoom normal'))   return document.body.style.zoom = '1';
    if (cmd.includes('imprimir'))      return window.print();
    if (cmd.includes('tela cheia') && !cmd.includes('vídeo')) {
      return document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen();
    }

    // ── MÍDIA ─────────────────────────────────────────────────────────────────
    if (cmd === 'play' || cmd === 'pausar') {
      const m = document.querySelector('video,audio');
      if (m) m.paused ? m.play() : m.pause();
      return;
    }
    if (cmd.includes('parar vídeo')) { const m = document.querySelector('video,audio'); if (m) { m.pause(); m.currentTime = 0; } return; }
    if (cmd.includes('avançar vídeo')) { const m = document.querySelector('video,audio'); if (m) m.currentTime += 10; return; }
    if (cmd.includes('voltar vídeo'))  { const m = document.querySelector('video,audio'); if (m) m.currentTime -= 10; return; }
    if (cmd.includes('aumentar volume')) { const m = document.querySelector('video,audio'); if (m) m.volume = Math.min(1, m.volume + 0.1); return; }
    if (cmd.includes('diminuir volume')) { const m = document.querySelector('video,audio'); if (m) m.volume = Math.max(0, m.volume - 0.1); return; }
    if (cmd.includes('silenciar') && !cmd.includes('aba')) { const m = document.querySelector('video,audio'); if (m) m.muted = !m.muted; return; }
    if (cmd.includes('tela cheia vídeo')) { const m = document.querySelector('video'); if (m) m.requestFullscreen(); return; }
  }
})();
