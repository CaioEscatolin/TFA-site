// background.js — Service Worker
// Lida com comandos de nível de NAVEGADOR (abas, janelas, favoritos,
// histórico, downloads) e com o clique no ícone da extensão, que
// mostra/oculta o widget injetado na página pelo content.js.

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'EXECUTE_BG_COMMAND') {
    const tabId = sender.tab ? sender.tab.id : null;
    handleCommand(message.cmd, tabId).catch(err => console.warn('Comando falhou:', err));
    sendResponse({ ok: true });
  }
  return true;
});

// Clique no ícone da extensão: mostra/oculta o widget na aba ativa.
chrome.action.onClicked.addListener(async (tab) => {
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_WIDGET' });
  } catch (e) {
    // Content script ainda não estava presente (ex.: aba aberta antes da
    // instalação/atualização da extensão). Injeta agora e tenta de novo.
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      await chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_WIDGET' });
    } catch (e2) {
      // Páginas internas do Chrome (chrome://, Web Store etc.) não
      // permitem extensões — não há como contornar essa restrição.
      console.warn('Não é possível ativar o widget nesta página:', e2);
    }
  }
});

async function getTab(tabId) {
  if (tabId != null) {
    try { return await chrome.tabs.get(tabId); } catch (e) { /* fallthrough */ }
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function handleCommand(cmd, tabId) {
  const t = await getTab(tabId);
  if (!t) return;

  // ── ABAS ─────────────────────────────────────────────────────────────────
  if (cmd.includes('nova aba'))     return chrome.tabs.create({});
  if (cmd.includes('duplicar aba')) return chrome.tabs.duplicate(t.id);
  if (cmd.includes('fechar aba'))   return chrome.tabs.remove(t.id);
  if (cmd.includes('restaurar aba')) return chrome.sessions.restore();

  if (cmd.includes('próxima aba')) {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const i = tabs.findIndex(x => x.active);
    return chrome.tabs.update(tabs[(i + 1) % tabs.length].id, { active: true });
  }
  if (cmd.includes('aba anterior')) {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const i = tabs.findIndex(x => x.active);
    return chrome.tabs.update(tabs[(i - 1 + tabs.length) % tabs.length].id, { active: true });
  }
  if (cmd.includes('fixar aba'))     return chrome.tabs.update(t.id, { pinned: !t.pinned });
  if (cmd.includes('silenciar aba')) return chrome.tabs.update(t.id, { muted: !t.mutedInfo?.muted });

  const abaNum = cmd.match(/^aba (\d+)$/);
  if (abaNum) {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const dest = tabs[parseInt(abaNum[1]) - 1];
    if (dest) return chrome.tabs.update(dest.id, { active: true });
    return;
  }

  // ── FAVORITOS ────────────────────────────────────────────────────────────
  if (cmd.includes('adicionar favorito')) return chrome.bookmarks.create({ title: t.title, url: t.url });
  if (cmd.includes('remover favorito')) {
    const r = await chrome.bookmarks.search({ url: t.url });
    if (r[0]) return chrome.bookmarks.remove(r[0].id);
    return;
  }
  if (cmd.includes('abrir favoritos') || cmd.includes('mostrar favoritos')) {
    return chrome.tabs.create({ url: 'chrome://bookmarks/' });
  }

  // ── HISTÓRICO ────────────────────────────────────────────────────────────
  if (cmd.includes('limpar histórico')) return chrome.tabs.create({ url: 'chrome://settings/clearBrowserData' });
  if (cmd.includes('abrir histórico'))  return chrome.tabs.create({ url: 'chrome://history/' });

  // ── DOWNLOADS ────────────────────────────────────────────────────────────
  if (cmd.includes('abrir downloads')) return chrome.tabs.create({ url: 'chrome://downloads/' });
  if (cmd.includes('baixar página'))   return chrome.downloads.download({ url: t.url });

  // ── JANELA ───────────────────────────────────────────────────────────────
  if (cmd.includes('nova janela'))    return chrome.windows.create({});
  if (cmd.includes('janela anônima')) return chrome.windows.create({ incognito: true });
  if (cmd.includes('fechar janela')) {
    const w = await chrome.windows.getCurrent();
    return chrome.windows.remove(w.id);
  }
}
